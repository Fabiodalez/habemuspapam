<?php
// header.php
function includeHeader($title = 'PapalBet') {
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?> - PapalBet</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f5f5f5;
        }
        
        .cardinal-card {
            position: relative;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            overflow: hidden;
            border: 1px solid #eee;
        }
        
        .cardinal-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .cardinal-image {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            overflow: hidden;
            border: 4px solid white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
            position: relative;
            z-index: 2;
            background-color: #f0f2f5;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .cardinal-card::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 120px;
            background: linear-gradient(135deg, #ff930f, #ffcc33);
            border-radius: 20px 20px 0 0;
            z-index: 1;
        }
        
        .gradient-btn {
            background: linear-gradient(to top, #ff930f, #ffcc33);
            color: white;
            transition: all 0.3s ease;
            border: none;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        
        .gradient-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 147, 15, 0.4);
        }
        
        .gradient-btn::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, #ff930f, #ffcc33);
            opacity: 0;
            z-index: -1;
            transition: opacity 0.3s ease;
        }
        
        .gradient-btn:hover::after {
            opacity: 1;
        }
        
        /* Header styles */
        .user-info-pill {
            background: linear-gradient(to right, rgba(255, 147, 15, 0.1), rgba(255, 204, 51, 0.1));
            border-radius: 50px;
            padding: 8px 16px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        
        .user-info-pill i {
            color: #ff930f;
            margin-right: 8px;
        }
        
        .balance-pill {
            background: linear-gradient(to right, rgba(255, 147, 15, 0.1), rgba(255, 204, 51, 0.1));
            border-radius: 50px;
            padding: 8px 16px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        
        .balance-pill i {
            color: #ff930f;
            margin-right: 8px;
        }
        
        .logo-text {
            color: #ff930f;
            position: relative;
        }
        
        
    </style>
</head>
<body class="min-h-screen">
    <header class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-4">
            <!-- Prima riga: Logo e Logout/Admin -->
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold logo-text">HabemusPapam</a>
                </div>
                
                <?php if (isLoggedIn()): ?>
                <div class="flex items-center space-x-2">
                    <?php if (isAdmin()): ?>
                    <a href="admin.php" class="text-[#ff930f] hover:text-[#ffcc33] px-4 py-2 rounded-full border border-[#ff930f] hover:border-[#ffcc33] transition-all">
                        <i class="fas fa-cog mr-1"></i> <span class="hidden sm:inline">Admin</span>
                    </a>
                    <?php endif; ?>
                    
                    <a href="logout.php" class="gradient-btn px-4 py-2 rounded-full font-medium">
                        <i class="fas fa-sign-out-alt mr-1"></i> <span class="hidden sm:inline">Logout</span>
                    </a>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if (isLoggedIn()): ?>
            <!-- Seconda riga: Info utente e saldo (responsive) -->
            <div class="mt-3 flex flex-wrap justify-center sm:justify-start gap-3">
                <div class="user-info-pill">
                    <i class="fas fa-user"></i>
                    <span class="font-medium"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                </div>
                
                <div class="balance-pill">
                    <i class="fas fa-coins"></i>
                    <span class="font-medium">€<?php echo number_format($_SESSION['balance'], 2, ',', '.'); ?></span>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </header>

    <main class="container mx-auto px-4 py-8">
<?php
}

// footer.php
function includeFooter() {
?>
    </main>

    <footer class="bg-white shadow-inner mt-8 py-6">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-4 md:mb-0">
                    <p class="text-gray-600"><i class="fa-brands fa-creative-commons-zero"></i> <?php echo date('Y'); ?> PapalBet. Nessun diritto riservato.</p>
                </div>
                 <div class="flex items-center">
                    
                    <label for="terms" class="ml-2 block text-sm text-gray-700">
                        Hai letto i  <a href="terms.php" class="text-[#ff930f] hover:underline">Termini di Servizio</a> e la <a href="terms.php" class="text-[#ff930f] hover:underline">Privacy Policy?</a>
                    </label>
                </div>
                <div>
                    <p class="text-gray-600">Scommetti anche tu sul prossimo morto (Forza Avellino!)</p>
                </div>
            </div>
        </div>
    </footer>
 </body>

<div id="creditModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-2xl shadow-lg w-full max-w-lg modal-content">
        <div class="flex justify-between items-center mb-4 border-b pb-3">
            <h3 class="text-xl font-bold text-gray-800">Nessun diritto riservato a:</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" onclick="closeCreditsModal()">
                <i class="fas fa-times fa-lg"></i>
            </button>
        </div>
        
        <div class="text-gray-700 mb-4">
            <p class="mb-3">Donne, neri, arabi, musulmani, rom/sinti, indigeni, immigrati, LGBTQ+, rifugiati, migranti, richiedenti asilo...</p>
        </div>
        
        <div class="flex justify-end">
            <button type="button" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-lg" onclick="closeCreditsModal()">
                Chiudi
            </button>
        </div>
    </div>
</div>

<script>
// Aggiungi questo script per gestire il modal
document.addEventListener('DOMContentLoaded', function() {
    // Aggiungi un listener al copyright nel footer
    const copyrightText = document.querySelector('footer .text-gray-600');
    if (copyrightText) {
        copyrightText.style.cursor = 'pointer';
        copyrightText.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('creditModal').classList.remove('hidden');
        });
    }
});

function closeCreditsModal() {
    document.getElementById('creditModal').classList.add('hidden');
}

// Chiudi con ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' || e.key === 'Esc') {
        closeCreditsModal();
    }
});
</script>
</body>
</html>
<?php
}
?>