<?php
// init_data.php - Script per inizializzare il database con dati di esempio
require_once 'config.php';

// Assicurati che la directory del database esista
$dbDir = dirname(DB_PATH);
if (!file_exists($dbDir)) {
    mkdir($dbDir, 0777, true);
    chmod($dbDir, 0777); // Assicura i permessi corretti
    echo "Directory del database creata.<br>";
}

// Verifica se il file del database esiste, altrimenti lo crea
if (!file_exists(DB_PATH)) {
    // Tenta di creare un file vuoto con i permessi corretti
    touch(DB_PATH);
    chmod(DB_PATH, 0666); // Assicura che il file sia scrivibile
    echo "File del database creato.<br>";
}

// Inizializza il database
echo "Inizializzazione del database...<br>";
initializeDatabase();

// Ottieni la connessione al database
try {
    $db = getDbConnection();
    echo "Connessione al database stabilita con successo.<br>";
    
    // Verifica che le tabelle esistano
    $result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='cardinals'");
    $tableExists = $result && $result->fetchColumn();
    
    if (!$tableExists) {
        die("La tabella 'cardinals' non esiste. Assicurati che il database sia inizializzato correttamente.");
    }
    
    // Svuota la tabella dei cardinali
    echo "Svuoto la tabella dei cardinali...<br>";
    $db->exec('DELETE FROM cardinals');
    echo "Tabella cardinali svuotata con successo.<br>";
    
    // Array dei cardinali di esempio
    $cardinalsData = [
        [
            'name' => 'Fridolin Ambongo Besungu',
            'age' => 65,
            'nation' => 'DR Congo',
            'continent' => 'Africa',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Cardinale congolese, arcivescovo di Kinshasa, noto per il suo impegno sociale e pastorale in Africa.',
            'bookmaker_odds' => 25.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Cardinal-Ambongo-Abaca-PressAlamy-license-purchased-e1733975578773-293x300.jpeg'
        ],
        [
            'name' => 'Anders Arborelius',
            'age' => 75,
            'nation' => 'Sweden',
            'continent' => 'Europe',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Primo cardinale svedese della storia, vescovo di Stoccolma, convertito al cattolicesimo da giovane.',
            'bookmaker_odds' => 35.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Screenshot-2024-12-01-at-10.56.57 PM-e1733090746218-300x290.png'
        ],
        [
            'name' => 'Jean-Marc Aveline',
            'age' => 66,
            'nation' => 'France',
            'continent' => 'Europe',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Marsiglia, esperto di dialogo interreligioso, particolarmente con l\'Islam.',
            'bookmaker_odds' => 15.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Cardinal-Aveline-Maria-Grazia-PicciarellaAlamy-1-1-300x284.jpeg'
        ],
        [
            'name' => 'Angelo Bagnasco',
            'age' => 82,
            'nation' => 'Italy',
            'continent' => 'Europe',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'non-voting',
            'position' => 'Emeritus',
            'description' => 'Arcivescovo emerito di Genova, è stato presidente della Conferenza Episcopale Italiana dal 2007 al 2017.',
            'bookmaker_odds' => 55.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Bagnasco-Photo-300x300.jpeg'
        ],
        [
            'name' => 'Charles Maung Bo',
            'age' => 76,
            'nation' => 'Myanmar',
            'continent' => 'Asia',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Yangon, primo cardinale del Myanmar, attivo nel dialogo interreligioso con buddhisti.',
            'bookmaker_odds' => 30.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Bo-Photo-credit-Mazur-Catholic-News-300x300.jpeg'
        ],
        [
            'name' => 'Stephen Brislin',
            'age' => 68,
            'nation' => 'South Africa',
            'continent' => 'Africa',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Città del Capo, Sudafrica, impegnato nelle questioni di giustizia sociale e nella lotta contro la povertà.',
            'bookmaker_odds' => 40.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Cardinal-Brislin-Diocese-of-Cape-Town-e1732644723191-300x291.jpg'
        ],
        [
            'name' => 'Raymond Leo Burke',
            'age' => 76,
            'nation' => 'United States of America',
            'continent' => 'North America',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'voting',
            'position' => 'Emeritus',
            'description' => 'Cardinale americano conservatore, noto per le sue posizioni tradizionali su liturgia e dottrina.',
            'bookmaker_odds' => 20.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Cardinal-Burke-copy-to-edit-copy-300x300.jpg'
        ],
        [
            'name' => 'Willem Jacobus Eijk',
            'age' => 71,
            'nation' => 'Netherlands',
            'continent' => 'Europe',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Utrecht, Paesi Bassi, teologo ed esperto di bioetica con un background medico.',
            'bookmaker_odds' => 42.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Eijk-285x300.jpg'
        ],
        [
            'name' => 'Péter Erdő',
            'age' => 72,
            'nation' => 'Hungary',
            'continent' => 'Europe',
            'created_by' => 'John Paul II',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Esztergom-Budapest, esperto in diritto canonico e figura di spicco nella Chiesa dell\'Europa centrale.',
            'bookmaker_odds' => 12.50,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Card.-Erdo-©-IEC-Budapest-e1740357183277-300x292.jpeg'
        ],
        [
            'name' => 'Fernando Filoni',
            'age' => 79,
            'nation' => 'Italy',
            'continent' => 'Europe',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'voting',
            'position' => 'Curial',
            'description' => 'Gran Maestro dell\'Ordine Equestre del Santo Sepolcro di Gerusalemme, ex Prefetto della Congregazione per l\'Evangelizzazione dei Popoli.',
            'bookmaker_odds' => 28.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Cardinal-Fernando-Filoni-Photo-from-the-Order-of-the-Holy-Sepulchre-e1732945931113-298x300.jpg'
        ],
        [
            'name' => 'Kurt Koch',
            'age' => 75,
            'nation' => 'Switzerland',
            'continent' => 'Europe',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'voting',
            'position' => 'Curial',
            'description' => 'Presidente del Pontificio Consiglio per la Promozione dell\'Unità dei Cristiani, figura chiave nel dialogo ecumenico.',
            'bookmaker_odds' => 18.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Cardinal-Koch-Photo-from-Wikipedia-Credit-to-RPP-Institut--300x300.jpg'
        ],
        [
            'name' => 'Gerhard Ludwig Müller',
            'age' => 77,
            'nation' => 'Germany',
            'continent' => 'Europe',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Emeritus',
            'description' => 'Ex Prefetto della Congregazione per la Dottrina della Fede, teologo e intellettuale di orientamento conservatore.',
            'bookmaker_odds' => 22.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Cardinal-Muller-Photo-by-Edward-Pentin-e1733317533722-300x269.jpeg'
        ],
        [
            'name' => 'Marc Ouellet',
            'age' => 80,
            'nation' => 'Canada',
            'continent' => 'North America',
            'created_by' => 'John Paul II',
            'voting_status' => 'non-voting',
            'position' => 'Emeritus',
            'description' => 'Ex Prefetto della Congregazione per i Vescovi, è stato arcivescovo di Québec ed era considerato papabile nel conclave del 2013.',
            'bookmaker_odds' => 60.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Cardinal-Ouellet-Photo-by-Edward-Pentin-copy-280x300.jpeg'
        ],
        [
            'name' => 'Pietro Parolin',
            'age' => 70,
            'nation' => 'Italy',
            'continent' => 'Europe',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Curial',
            'description' => 'Segretario di Stato Vaticano, diplomatico esperto e stretto collaboratore di Papa Francesco.',
            'bookmaker_odds' => 5.50,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Parolin-Photo-300x300.jpeg'
        ],
        [
            'name' => 'Mauro Piacenza',
            'age' => 80,
            'nation' => 'Italy',
            'continent' => 'Europe',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'non-voting',
            'position' => 'Emeritus',
            'description' => 'Penitenziere Maggiore emerito, ha servito in vari dicasteri della Curia Romana.',
            'bookmaker_odds' => 65.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Cardinal-Piacenza-Photo-from-Book-e1733262433154-300x270.jpg'
        ],
        [
            'name' => 'Pierbattista Pizzaballa',
            'age' => 60,
            'nation' => 'Jerusalem',
            'continent' => 'Asia',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Patriarca Latino di Gerusalemme, esperto del Medio Oriente e voce importante nel dialogo israeliano-palestinese.',
            'bookmaker_odds' => 8.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Cardinal-Pierbattista-Pizzaballa-Reuters-Photo-license-purchased-e1733919950642-300x278.jpg'
        ],
        [
            'name' => 'Albert Malcolm Ranjith Patabendige Don',
            'age' => 77,
            'nation' => 'Sri Lanka',
            'continent' => 'Asia',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Colombo, Sri Lanka, noto per le sue posizioni tradizionaliste sulla liturgia.',
            'bookmaker_odds' => 32.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Ranjith-e1725194111365-300x300.jpg'
        ],
        [
            'name' => 'Robert Sarah',
            'age' => 79,
            'nation' => 'Guinea',
            'continent' => 'Africa',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'voting',
            'position' => 'Emeritus',
            'description' => 'Ex Prefetto della Congregazione per il Culto Divino, figura di spicco dell\'ala conservatrice della Chiesa.',
            'bookmaker_odds' => 10.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Sarah-e1725197321247-300x300.jpg'
        ],
        [
            'name' => 'Daniel Fernando Sturla',
            'age' => 65,
            'nation' => 'Uruguay',
            'continent' => 'South America',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Montevideo, salesiano, impegnato nell\'evangelizzazione in contesti secolarizzati.',
            'bookmaker_odds' => 45.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/11/Cardinal-Daniel-Fernando-Sturla-Berhouet-Abaca-Press-Alamy-e1733993095768-300x283.jpg'
        ],
        [
            'name' => 'Luis Antonio Gokim Tagle',
            'age' => 67,
            'nation' => 'Philippines',
            'continent' => 'Asia',
            'created_by' => 'Benedict XVI',
            'voting_status' => 'voting',
            'position' => 'Curial',
            'description' => 'Pro-Prefetto del Dicastero per l\'Evangelizzazione, ex arcivescovo di Manila, molto popolare per il suo carisma e umiltà.',
            'bookmaker_odds' => 6.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Tagle-Photo-1-300x300.jpg'
        ],
        [
            'name' => 'José Tolentino de Mendonça',
            'age' => 59,
            'nation' => 'Portugal',
            'continent' => 'Europe',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Curial',
            'description' => 'Prefetto del Dicastero per la Cultura e l\'Educazione, teologo, poeta e intellettuale.',
            'bookmaker_odds' => 15.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Mendonca-Edward-Pentin-e1733856006255-293x300.jpeg'
        ],
        [
            'name' => 'Matteo Maria Zuppi',
            'age' => 69,
            'nation' => 'Italy',
            'continent' => 'Europe',
            'created_by' => 'Francis',
            'voting_status' => 'voting',
            'position' => 'Diocesan',
            'description' => 'Arcivescovo di Bologna e presidente della Conferenza Episcopale Italiana, legato alla Comunità di Sant\'Egidio.',
            'bookmaker_odds' => 7.00,
            'image_url' => 'https://collegeofcardinalsreport.com/wp-content/uploads/2024/07/Zuppi-e1725196835772-300x300.jpg'
        ]
    ];

    // Prepara lo statement per l'inserimento
    echo "Preparazione dello statement per l'inserimento...<br>";
    $stmt = $db->prepare('
        INSERT INTO cardinals 
        (name, age, nation, continent, created_by, voting_status, position, description, bookmaker_odds, image_url) 
        VALUES 
        (:name, :age, :nation, :continent, :created_by, :voting_status, :position, :description, :bookmaker_odds, :image_url)
    ');

    // Inserisci i cardinali di esempio
    $success = 0;
    foreach ($cardinalsData as $cardinal) {
        try {
            $stmt->bindParam(':name', $cardinal['name']);
            $stmt->bindParam(':age', $cardinal['age']);
            $stmt->bindParam(':nation', $cardinal['nation']);
            $stmt->bindParam(':continent', $cardinal['continent']);
            $stmt->bindParam(':created_by', $cardinal['created_by']);
            $stmt->bindParam(':voting_status', $cardinal['voting_status']);
            $stmt->bindParam(':position', $cardinal['position']);
            $stmt->bindParam(':description', $cardinal['description']);
            $stmt->bindParam(':bookmaker_odds', $cardinal['bookmaker_odds']);
            $stmt->bindParam(':image_url', $cardinal['image_url']);
            
            $stmt->execute();
            $success++;
            echo "Inserito cardinale: " . $cardinal['name'] . "<br>";
        } catch (PDOException $e) {
            echo "Errore durante l'inserimento del cardinale " . $cardinal['name'] . ": " . $e->getMessage() . "<br>";
        }
    }

    echo "<div style='background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>
        Dati di esempio inizializzati con successo! Sono stati inseriti $success cardinali.
    </div>";
    
} catch (PDOException $e) {
    die("<div style='background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>
        Errore durante l'esecuzione dello script: " . $e->getMessage() . "
    </div>");
}