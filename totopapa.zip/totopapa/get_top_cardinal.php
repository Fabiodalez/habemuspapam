<?php
// get_top_cardinal.php - API per ottenere il cardinale con più scommesse

require_once 'config.php';

header('Content-Type: application/json');

// (Opzionale) Verifica che l'utente sia loggato
if (!isLoggedIn()) {
    echo json_encode(['error' => 'Utente non autenticato']);
    exit;
}

try {
    $db = getDbConnection();

    // Calcola il totale scommesso per ogni cardinale e prendi il primo
    $sql = "
        SELECT 
            c.id,
            c.name,
            c.image_url,
            SUM(b.amount) AS total_amount
        FROM bets b
        JOIN cardinals c ON b.cardinal_id = c.id
        GROUP BY c.id, c.name, c.image_url
        ORDER BY total_amount DESC
        LIMIT 1
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $top = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$top) {
        echo json_encode(['error' => 'Nessuna scommessa trovata']);
        exit;
    }

    // Forza casting
    $top['total_amount'] = (float) $top['total_amount'];

    echo json_encode([
        'id'           => (int)   $top['id'],
        'name'         =>          $top['name'],
        'image_url'    =>          $top['image_url'],
        'total_amount' =>          $top['total_amount']
    ]);

} catch (PDOException $e) {
    echo json_encode(['error' => 'Errore di database: ' . $e->getMessage()]);
    exit;
}
