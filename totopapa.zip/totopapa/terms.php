<?php
// terms.php - Pagina dei Termini di Servizio
require_once 'config.php';
require_once 'header_footer.php';

// Includi l'header
includeHeader('Termini di Servizio');
?>

<!-- Google Font Outfit -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Outfit', sans-serif;
        background-color: #f5f5f5;
    }

    .terms-container {
        background-color: white;
        border-radius: 20px;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
        padding: 2rem;
        margin-bottom: 2rem;
    }

    .terms-title {
        color: #ff930f;
        position: relative;
        display: inline-block;
        margin-bottom: 1.5rem;
    }

    .terms-title::after {
        content: "";
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 50px;
        height: 3px;
        background: linear-gradient(to right, #ff930f, #ffcc33);
        border-radius: 3px;
    }

    .section-title {
        color: #ff930f;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
    }

    .subsection-title {
        font-weight: 600;
        margin-top: 1rem;
        margin-bottom: 0.5rem;
    }

    .section-content p {
        margin-bottom: 1rem;
        line-height: 1.6;
    }

    .section-content ul {
        margin-bottom: 1rem;
        padding-left: 1.5rem;
    }

    .section-content li {
        margin-bottom: 0.5rem;
        line-height: 1.5;
    }

    .back-button {
        background: linear-gradient(to top, #ff930f, #ffcc33);
        color: white;
        transition: all 0.3s ease;
        border: none;
        position: relative;
        overflow: hidden;
        z-index: 1;
        display: inline-block;
        padding: 0.75rem 1.5rem;
        border-radius: 9999px;
        font-weight: 600;
        margin-top: 1rem;
        text-decoration: none;
    }

    .back-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(255, 147, 15, 0.4);
    }

    .back-button::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(to bottom, #ff930f, #ffcc33);
        opacity: 0;
        z-index: -1;
        transition: opacity 0.3s ease;
    }

    .back-button:hover::after {
        opacity: 1;
    }

    /* Animazioni */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .animate-fadeIn {
        animation: fadeIn 0.5s ease forwards;
    }
</style>

<div class="mb-8 animate-fadeIn">
    <h1 class="text-4xl font-bold mb-3 terms-title">Termini di Servizio</h1>
    <p class="text-gray-600 text-lg">
        Leggi attentamente i termini e le condizioni di utilizzo di PapalBet.
    </p>
</div>

<div class="terms-container animate-fadeIn">
    <div class="section-content">
        <h2 class="text-2xl font-bold section-title">1. Introduzione</h2>
        <p>
            Benvenuto su "Habemus Papam" (di seguito "PapalBet", "la Piattaforma" o "il Sito"), un sito di scommesse virtuali sulle elezioni papali. Questi Termini di Servizio ("Termini") regolano l'utilizzo della Piattaforma e costituiscono un accordo legalmente vincolante tra te e l'amministratore del Sito.
        </p>
        
        <h2 class="text-2xl font-bold section-title">2. Natura Ludica del Servizio</h2>
        <div class="mb-4">
            <p class="subsection-title">2.1 Gioco Virtuale.</p>
            <p>PapalBet è una piattaforma di intrattenimento progettata esclusivamente a scopo ludico. Tutte le attività svolte sulla Piattaforma sono da considerarsi parte di un gioco virtuale senza alcun valore legale o economico reale.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">2.2 Assenza di Premi in Denaro.</p>
            <p>Si specifica esplicitamente che non ci sono soldi veri in palio, premi monetari o qualsiasi altro tipo di ricompensa materiale derivante dall'utilizzo della Piattaforma.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">2.3 Valuta Virtuale.</p>
            <p>A ciascun utente registrato vengono assegnati 1000€ (euro) di valuta virtuale da utilizzare esclusivamente all'interno della Piattaforma. Tale valuta:</p>
            <ul class="list-disc pl-6 mt-2">
                <li>Non ha alcun valore reale</li>
                <li>Non può essere convertita in denaro reale</li>
                <li>Non può essere trasferita al di fuori della Piattaforma</li>
                <li>Non può essere acquistata con denaro reale</li>
                <li>Non costituisce alcun credito o titolo nei confronti dell'amministratore della Piattaforma</li>
            </ul>
        </div>
        
        <h2 class="text-2xl font-bold section-title">3. Esonero di Responsabilità</h2>
        <div class="mb-4">
            <p class="subsection-title">3.1 Natura Scherzosa.</p>
            <p>PapalBet è stato creato con spirito di leggerezza e intrattenimento. La Piattaforma è da intendersi come uno scherzo e un passatempo, e come tale dovrebbe essere interpretata dagli utenti.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">3.2 Limitazione di Responsabilità.</p>
            <p>L'amministratore della Piattaforma non è responsabile per:</p>
            <ul class="list-disc pl-6 mt-2">
                <li>Eventuali danni diretti, indiretti, incidentali, consequenziali o punitivi derivanti dall'utilizzo o dall'impossibilità di utilizzare il Servizio</li>
                <li>Qualsiasi malinteso sul carattere ludico della Piattaforma</li>
                <li>Disguidi tecnici, interruzioni o malfunzionamenti della Piattaforma</li>
                <li>Qualsiasi contenuto o commento pubblicato dagli utenti</li>
            </ul>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">3.3 Nessuna Relazione con Istituzioni Religiose.</p>
            <p>Si precisa che la Piattaforma non ha alcun legame ufficiale con il Vaticano, la Santa Sede o qualsiasi altra istituzione religiosa. Ogni riferimento a cardinali, procedure o eventi legati al conclave papale è da intendersi come semplice spunto tematico per il gioco.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">4. Protezione dei Dati Personali</h2>
        <div class="mb-4">
            <p class="subsection-title">4.1 Raccolta Minima di Dati.</p>
            <p>La Piattaforma richiede solo le informazioni minime necessarie per la registrazione (username e password). Non vengono raccolti dati personali sensibili.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">4.2 Assenza di Verifiche.</p>
            <p>Non viene richiesta la verifica dell'indirizzo email o qualsiasi altra forma di autenticazione dell'identità reale.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">4.3 Limitazione nell'Uso dei Dati.</p>
            <p>I dati forniti dagli utenti:</p>
            <ul class="list-disc pl-6 mt-2">
                <li>Non verranno condivisi o ceduti a terze parti</li>
                <li>Non verranno utilizzati per scopi commerciali o pubblicitari</li>
                <li>Non verranno utilizzati per scopi esterni alla Piattaforma</li>
                <li>Verranno conservati solo per il tempo necessario al funzionamento della Piattaforma</li>
            </ul>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">4.4 Cookie e Tracciamento.</p>
            <p>La Piattaforma utilizza solo i cookie essenziali per il funzionamento tecnico del Sito. Non vengono utilizzati cookie di profilazione o di tracciamento per fini commerciali.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">5. Diritti dell'Amministratore</h2>
        <div class="mb-4">
            <p class="subsection-title">5.1 Chiusura della Piattaforma.</p>
            <p>L'amministratore si riserva il diritto insindacabile e incondizionato di:</p>
            <ul class="list-disc pl-6 mt-2">
                <li>Chiudere temporaneamente o permanentemente la Piattaforma in qualsiasi momento e senza preavviso</li>
                <li>Modificare, sospendere o interrompere qualsiasi aspetto del Servizio</li>
                <li>Rimuovere account o contenuti a propria discrezione</li>
            </ul>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">5.2 Modifiche ai Termini.</p>
            <p>L'amministratore si riserva il diritto di modificare questi Termini in qualsiasi momento. Continuando a utilizzare la Piattaforma dopo tali modifiche, l'utente accetta di essere vincolato dai Termini aggiornati.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">6. Regole di Scommessa</h2>
        <div class="mb-4">
            <p class="subsection-title">6.1 Periodo di Scommessa.</p>
            <p>Gli utenti possono piazzare e modificare le proprie scommesse fino all'attivazione della "Modalità Conclave". Una volta attivata tale modalità, non sarà più possibile piazzare nuove scommesse, modificare quelle esistenti o ritirare scommesse già effettuate.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">6.2 Assegnazione dei Risultati.</p>
            <p>L'esito delle scommesse sarà determinato sulla base dei risultati ufficiali dell'elezione papale. L'amministratore della Piattaforma è l'unico arbitro per la determinazione dei risultati e la sua decisione è finale e inappellabile.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">6.3 Reset del Sistema.</p>
            <p>L'amministratore si riserva il diritto di azzerare tutte le scommesse e ricaricare il saldo virtuale di ciascun utente in qualsiasi momento e per qualsiasi motivo, senza che ciò comporti alcun diritto di risarcimento per gli utenti.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">7. Codice di Condotta</h2>
        <div class="mb-4">
            <p class="subsection-title">7.1 Comportamento degli Utenti.</p>
            <p>Gli utenti si impegnano a:</p>
            <ul class="list-disc pl-6 mt-2">
                <li>Non utilizzare linguaggio offensivo, diffamatorio o blasfemo</li>
                <li>Non creare account multipli per aggirare le limitazioni del sistema</li>
                <li>Non tentare di manipolare o hackerare il sistema di scommesse</li>
                <li>Rispettare il carattere ludico e scherzoso della Piattaforma</li>
            </ul>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">7.2 Sospensione degli Account.</p>
            <p>L'amministratore si riserva il diritto di sospendere o eliminare gli account che violano questi Termini o che, a suo insindacabile giudizio, utilizzano la Piattaforma in modo inappropriato.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">8. Proprietà Intellettuale</h2>
        <div class="mb-4">
            <p class="subsection-title">8.1 Contenuti del Sito.</p>
            <p>Tutti i contenuti presenti sulla Piattaforma, inclusi ma non limitati a testi, grafica, logo, immagini e software, sono di proprietà dell'amministratore o dei rispettivi titolari e sono protetti dalle leggi sul copyright.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">8.2 Licenza Limitata.</p>
            <p>All'utente viene concessa una licenza limitata, non esclusiva e non trasferibile per accedere e utilizzare la Piattaforma per scopi personali e non commerciali.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">9. Limitazioni Geografiche e di Età</h2>
        <div class="mb-4">
            <p class="subsection-title">9.1 Età Minima.</p>
            <p>L'utilizzo della Piattaforma è riservato a utenti di età pari o superiore a 18 anni. Registrandosi, l'utente dichiara e garantisce di avere almeno 18 anni.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">9.2 Restrizioni Geografiche.</p>
            <p>L'utente è responsabile di verificare che l'utilizzo della Piattaforma sia conforme alle leggi locali della propria giurisdizione. L'amministratore non garantisce che la Piattaforma sia appropriata o disponibile per l'uso in località specifiche.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">10. Disposizioni Finali</h2>
        <div class="mb-4">
            <p class="subsection-title">10.1 Legge Applicabile.</p>
            <p>Questi Termini sono regolati e interpretati in conformità con le leggi italiane, senza riguardo ai principi di conflitto di leggi.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">10.2 Separabilità.</p>
            <p>Se una qualsiasi disposizione di questi Termini dovesse essere ritenuta illegale, nulla o per qualsiasi motivo inapplicabile, tale disposizione sarà considerata separabile da questi Termini e non influirà sulla validità e l'applicabilità delle disposizioni rimanenti.</p>
        </div>
        
        <div class="mb-4">
            <p class="subsection-title">10.3 Contatti.</p>
            <p>Per qualsiasi domanda riguardante questi Termini, gli utenti possono contattare l'amministratore attraverso i canali indicati sulla Piattaforma.</p>
        </div>
        
        <h2 class="text-2xl font-bold section-title">11. Accettazione dei Termini</h2>
        <p>
            Utilizzando PapalBet, l'utente conferma di aver letto, compreso e accettato integralmente questi Termini di Servizio. Se non si accettano questi Termini, si prega di non utilizzare la Piattaforma.
        </p>

        <div class="mt-6 mb-2 border-t border-gray-200 pt-4 text-gray-500 text-sm text-right">
            <p>Ultimo aggiornamento: 24 aprile 2025</p>
        </div>
    </div>
</div>

<div class="text-center mb-8">
    <a href="index.php" class="back-button">
        <i class="fas fa-arrow-left mr-2"></i> Torna alla pagina principale
    </a>
</div>

<?php
// Includi il footer
includeFooter();
?>