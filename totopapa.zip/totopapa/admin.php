<?php
// admin.php - Pannello di amministrazione
require_once 'config.php';
require_once 'header_footer.php';

// Verifica che l'utente sia un amministratore
if (!isLoggedIn() || !isAdmin()) {
    redirect('index.php');
}

// Ottieni la connessione al database
$db = getDbConnection();

// Recupera lo stato corrente della modalità Conclave
$stmt_settings = $db->query("SELECT value FROM settings WHERE name = 'conclave'");
$setting = $stmt_settings->fetch(PDO::FETCH_ASSOC);
$conclave_mode_active = ($setting && $setting['value'] === '1');

// Gestione delle azioni
$message = '';
$messageType = '';

// Azione: Attiva/Disattiva modalità Conclave
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggleConclave') {
    $newConclaveState = $conclave_mode_active ? '0' : '1';
    
    try {
        // Controlla se l'impostazione esiste già
        $stmt_check = $db->prepare("SELECT COUNT(*) FROM settings WHERE name = 'conclave'");
        $stmt_check->execute();
        $settingExists = $stmt_check->fetchColumn() > 0;
        
        if ($settingExists) {
            // Aggiorna l'impostazione esistente
            $stmt = $db->prepare("UPDATE settings SET value = :value WHERE name = 'conclave'");
        } else {
            // Inserisci una nuova impostazione
            $stmt = $db->prepare("INSERT INTO settings (name, value) VALUES ('conclave', :value)");
        }
        
        $stmt->bindParam(':value', $newConclaveState);
        $stmt->execute();
        
        // Aggiorna la variabile di stato
        $conclave_mode_active = $newConclaveState === '1';
        
        $message = 'Modalità Conclave ' . ($conclave_mode_active ? 'attivata' : 'disattivata') . ' con successo';
        $messageType = 'success';
    } catch (PDOException $e) {
        $message = 'Errore durante la modifica della modalità Conclave: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Azione: Aggiungi/Modifica Cardinale
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'saveCardinal') {
        $cardinalId = isset($_POST['cardinal_id']) ? (int)$_POST['cardinal_id'] : 0;
        $name = $_POST['name'] ?? '';
        $age = $_POST['age'] ? (int)$_POST['age'] : null;
        $nation = $_POST['nation'] ?? '';
        $continent = $_POST['continent'] ?? '';
        $createdBy = $_POST['created_by'] ?? '';
        $votingStatus = $_POST['voting_status'] ?? '';
        $position = $_POST['position'] ?? '';
        $description = $_POST['description'] ?? '';
        $bookmakerOdds = $_POST['bookmaker_odds'] ? (float)$_POST['bookmaker_odds'] : 0;
        $imageUrl = $_POST['image_url'] ?? '';
        
        if (empty($name)) {
            $message = 'Il nome del cardinale è obbligatorio';
            $messageType = 'error';
        } else {
            try {
                if ($cardinalId > 0) {
                    // Aggiorna un cardinale esistente
                    $stmt = $db->prepare('
                        UPDATE cardinals 
                        SET name = :name, age = :age, nation = :nation, continent = :continent, 
                            created_by = :created_by, voting_status = :voting_status, position = :position, 
                            description = :description, bookmaker_odds = :bookmaker_odds, image_url = :image_url,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = :id
                    ');
                    $stmt->bindParam(':id', $cardinalId);
                    $message = 'Cardinale aggiornato con successo';
                } else {
                    // Inserisci un nuovo cardinale
                    $stmt = $db->prepare('
                        INSERT INTO cardinals 
                        (name, age, nation, continent, created_by, voting_status, position, description, bookmaker_odds, image_url) 
                        VALUES 
                        (:name, :age, :nation, :continent, :created_by, :voting_status, :position, :description, :bookmaker_odds, :image_url)
                    ');
                    $message = 'Cardinale aggiunto con successo';
                }
                
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':age', $age);
                $stmt->bindParam(':nation', $nation);
                $stmt->bindParam(':continent', $continent);
                $stmt->bindParam(':created_by', $createdBy);
                $stmt->bindParam(':voting_status', $votingStatus);
                $stmt->bindParam(':position', $position);
                $stmt->bindParam(':description', $description);
                $stmt->bindParam(':bookmaker_odds', $bookmakerOdds);
                $stmt->bindParam(':image_url', $imageUrl);
                
                $stmt->execute();
                $messageType = 'success';
            } catch (PDOException $e) {
                $message = 'Errore: ' . $e->getMessage();
                $messageType = 'error';
            }
        }
    } 
    // Azione: Elimina Cardinale
    elseif ($_POST['action'] === 'deleteCardinal' && isset($_POST['cardinal_id'])) {
        $cardinalId = (int)$_POST['cardinal_id'];
        
        try {
            // Verifica se ci sono scommesse su questo cardinale
            $stmt = $db->prepare('SELECT COUNT(*) FROM bets WHERE cardinal_id = :cardinal_id');
            $stmt->bindParam(':cardinal_id', $cardinalId);
            $stmt->execute();
            $betCount = $stmt->fetchColumn();
            
            if ($betCount > 0) {
                $message = 'Impossibile eliminare il cardinale perché ci sono scommesse associate';
                $messageType = 'error';
            } else {
                $stmt = $db->prepare('DELETE FROM cardinals WHERE id = :id');
                $stmt->bindParam(':id', $cardinalId);
                $stmt->execute();
                
                $message = 'Cardinale eliminato con successo';
                $messageType = 'success';
            }
        } catch (PDOException $e) {
            $message = 'Errore: ' . $e->getMessage();
            $messageType = 'error';
        }
    }
    // Azione: Aggiungi Utente
    elseif ($_POST['action'] === 'addUser') {
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? ''; // Aggiungiamo campo email
        $password = $_POST['password'] ?? '';
        $isAdmin = isset($_POST['is_admin']) && $_POST['is_admin'] == 1 ? 1 : 0;
        
        if (empty($username) || empty($password) || empty($email)) {
            $message = 'Username, email e password sono obbligatori';
            $messageType = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Formato email non valido';
            $messageType = 'error';
        } else {
            try {
                // Verifica se l'username o l'email esistono già
                $stmt = $db->prepare('SELECT COUNT(*) FROM users WHERE username = :username OR email = :email');
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                
                if ($stmt->fetchColumn() > 0) {
                    $message = 'L\'username o l\'email sono già in uso';
                    $messageType = 'error';
                } else {
                    // Hash della password
                    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                    
                    // Inserisci il nuovo utente
                    $stmt = $db->prepare('
                        INSERT INTO users (username, email, password, is_admin) 
                        VALUES (:username, :email, :password, :is_admin)
                    ');
                    $stmt->bindParam(':username', $username);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':password', $passwordHash);
                    $stmt->bindParam(':is_admin', $isAdmin);
                    $stmt->execute();
                    
                    $message = 'Utente aggiunto con successo';
                    $messageType = 'success';
                }
            } catch (PDOException $e) {
                $message = 'Errore: ' . $e->getMessage();
                $messageType = 'error';
            }
        }
    }
}

// Recupera tutti i cardinali
$stmt = $db->query('SELECT * FROM cardinals ORDER BY name ASC');
$cardinals = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Recupera tutti gli utenti con email
$stmt = $db->query('SELECT id, username, email, balance, is_admin, created_at FROM users ORDER BY username ASC');
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Includi l'header
includeHeader('Pannello di Amministrazione');
?>

<div class="bg-white shadow rounded-lg mb-8">
    <div class="p-6">
        <h1 class="text-2xl font-bold text-gray-800 mb-4">Pannello di Amministrazione</h1>
        
        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded <?php echo $messageType === 'error' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Aggiungiamo qui la sezione per la modalità Conclave -->
        <div class="mb-8 p-6 bg-gray-50 rounded-lg shadow-sm">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-xl font-bold text-gray-800 mb-2">Modalità Conclave</h2>
                    <p class="text-gray-600 mb-4">
                        Quando la modalità Conclave è attiva, gli utenti non possono più piazzare, modificare o eliminare le scommesse.
                        Attiva questa modalità quando inizia il vero Conclave.
                    </p>
                    <div class="flex items-center">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium mr-3 <?php echo $conclave_mode_active ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'; ?>">
                            <span class="w-2 h-2 rounded-full mr-1 <?php echo $conclave_mode_active ? 'bg-yellow-500' : 'bg-gray-500'; ?>"></span>
                            Stato attuale: <?php echo $conclave_mode_active ? 'Conclave ATTIVO' : 'Conclave NON attivo'; ?>
                        </span>
                    </div>
                </div>
                <form method="POST" action="admin.php">
                    <input type="hidden" name="action" value="toggleConclave">
                    <button type="submit" class="<?php echo $conclave_mode_active ? 'bg-red-500 hover:bg-red-600' : 'bg-yellow-500 hover:bg-yellow-600'; ?> text-white font-bold py-3 px-6 rounded-lg shadow-md transition-all">
                        <?php if ($conclave_mode_active): ?>
                            <i class="fas fa-door-open mr-2"></i> Disattiva Modalità Conclave
                        <?php else: ?>
                            <i class="fas fa-door-closed mr-2"></i> Attiva Modalità Conclave
                        <?php endif; ?>
                    </button>
                </form>
            </div>
        </div>
        
        <div class="mb-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-gray-800">Gestione Cardinali</h2>
                <button type="button" class="gradient-btn px-4 py-2 rounded-full font-medium" onclick="openCardinalModal()">
                    <i class="fas fa-plus mr-1"></i> Aggiungi Cardinale
                </button>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead>
                        <tr class="bg-gray-100 text-gray-600 text-sm leading-normal">
                            <th class="py-3 px-6 text-left">Nome</th>
                            <th class="py-3 px-6 text-left">Età</th>
                            <th class="py-3 px-6 text-left">Nazione</th>
                            <th class="py-3 px-6 text-left">Continente</th>
                            <th class="py-3 px-6 text-left">Creato da</th>
                            <th class="py-3 px-6 text-left">Votante</th>
                            <th class="py-3 px-6 text-left">Quota</th>
                            <th class="py-3 px-6 text-center">Azioni</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 text-sm">
                        <?php foreach ($cardinals as $cardinal): ?>
                        <tr class="border-b border-gray-200 hover:bg-gray-50">
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($cardinal['name']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo $cardinal['age']; ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($cardinal['nation']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($cardinal['continent']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($cardinal['created_by']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo $cardinal['voting_status'] === 'voting' ? 'Sì' : 'No'; ?></td>
                            <td class="py-3 px-6 text-left"><?php echo number_format($cardinal['bookmaker_odds'], 2, ',', '.'); ?></td>
                            <td class="py-3 px-6 text-center">
                                <button type="button" class="text-blue-500 hover:text-blue-700 mr-2" onclick="editCardinal(<?php echo htmlspecialchars(json_encode($cardinal)); ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button type="button" class="text-red-500 hover:text-red-700" onclick="deleteCardinal(<?php echo $cardinal['id']; ?>, '<?php echo addslashes($cardinal['name']); ?>')">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div>
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-gray-800">Gestione Utenti</h2>
                <button type="button" class="gradient-btn px-4 py-2 rounded-full font-medium" onclick="openUserModal()">
                    <i class="fas fa-plus mr-1"></i> Aggiungi Utente
                </button>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead>
                        <tr class="bg-gray-100 text-gray-600 text-sm leading-normal">
                            <th class="py-3 px-6 text-left">Username</th>
                            <th class="py-3 px-6 text-left">Email</th>
                            <th class="py-3 px-6 text-left">Saldo</th>
                            <th class="py-3 px-6 text-left">Admin</th>
                            <th class="py-3 px-6 text-left">Data Creazione</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 text-sm">
                        <?php foreach ($users as $user): ?>
                        <tr class="border-b border-gray-200 hover:bg-gray-50">
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($user['username']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($user['email']); ?></td>
                            <td class="py-3 px-6 text-left">€<?php echo number_format($user['balance'], 2, ',', '.'); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo $user['is_admin'] ? 'Sì' : 'No'; ?></td>
                            <td class="py-3 px-6 text-left"><?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal per aggiungere/modificare un cardinale -->
<div id="cardinalModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-2xl max-h-screen overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-gray-800" id="cardinalModalTitle">Aggiungi Cardinale</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" onclick="closeCardinalModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <form id="cardinalForm" method="POST" action="admin.php">
            <input type="hidden" name="action" value="saveCardinal">
            <input type="hidden" id="cardinal_id" name="cardinal_id" value="">
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Nome *</label>
                    <input type="text" id="name" name="name" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                </div>
                
                <div>
                    <label for="age" class="block text-gray-700 text-sm font-bold mb-2">Età</label>
                    <input type="number" id="age" name="age" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div>
                    <label for="nation" class="block text-gray-700 text-sm font-bold mb-2">Nazione</label>
                    <input type="text" id="nation" name="nation" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div>
                    <label for="continent" class="block text-gray-700 text-sm font-bold mb-2">Continente</label>
                    <select id="continent" name="continent" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="">Seleziona...</option>
                        <option value="Africa">Africa</option>
                        <option value="Asia">Asia</option>
                        <option value="Europe">Europa</option>
                        <option value="North America">Nord America</option>
                        <option value="South America">Sud America</option>
                        <option value="Oceania">Oceania</option>
                    </select>
                </div>
                
                <div>
                    <label for="created_by" class="block text-gray-700 text-sm font-bold mb-2">Creato da</label>
                    <select id="created_by" name="created_by" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="">Seleziona...</option>
                        <option value="John Paul II">Giovanni Paolo II</option>
                        <option value="Benedict XVI">Benedetto XVI</option>
                        <option value="Francis">Francesco</option>
                    </select>
                </div>
                
                <div>
                    <label for="voting_status" class="block text-gray-700 text-sm font-bold mb-2">Stato di voto</label>
                    <select id="voting_status" name="voting_status" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="voting">Votante</option>
                        <option value="non-voting">Non Votante</option>
                    </select>
                </div>
                
                <div>
                    <label for="position" class="block text-gray-700 text-sm font-bold mb-2">Posizione</label>
                    <select id="position" name="position" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="">Seleziona...</option>
                        <option value="Diocesan">Diocesano</option>
                        <option value="Curial">Curiale</option>
                        <option value="Emeritus">Emerito</option>
                    </select>
                </div>
                
                <div>
                    <label for="bookmaker_odds" class="block text-gray-700 text-sm font-bold mb-2">Quota bookmaker</label>
                    <input type="number" id="bookmaker_odds" name="bookmaker_odds" step="0.01" min="0" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
            </div>
            
            <div class="mb-4">
                <label for="image_url" class="block text-gray-700 text-sm font-bold mb-2">URL Immagine</label>
                <input type="text" id="image_url" name="image_url" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
            </div>
            
            <div class="mb-4">
                <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Descrizione</label>
                <textarea id="description" name="description" rows="4" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
            </div>
            
            <div class="flex justify-end">
                <button type="button" class="mr-2 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onclick="closeCardinalModal()">
                    Annulla
                </button>
                <button type="submit" class="gradient-btn px-4 py-2 rounded-full font-medium">
                    Salva
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal per aggiungere un utente -->
<div id="userModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-gray-800">Aggiungi Utente</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" onclick="closeUserModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <form method="POST" action="admin.php">
            <input type="hidden" name="action" value="addUser">
            
            <div class="mb-4">
                <label for="username" class="block text-gray-700 text-sm font-bold mb-2">Username *</label>
                <input type="text" id="username" name="username" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>
            
            <div class="mb-4">
                <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email *</label>
                <input type="email" id="email" name="email" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>
            
            <div class="mb-4">
                <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password *</label>
                <input type="password" id="password" name="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>
            
            <div class="mb-4">
                <label class="flex items-center">
                    <input type="checkbox" name="is_admin" value="1" class="mr-2">
                    <span class="text-gray-700 text-sm font-bold">Amministratore</span>
                </label>
            </div>
            
            <div class="flex justify-end">
                <button type="button" class="mr-2 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onclick="closeUserModal()">
                    Annulla
                </button>
                <button type="submit" class="gradient-btn px-4 py-2 rounded-full font-medium">
                    Aggiungi
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal per confermare eliminazione -->
<div id="deleteModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <div class="mb-4">
            <h3 class="text-xl font-bold text-gray-800">Conferma eliminazione</h3>
            <p class="text-gray-600 mt-2" id="deleteConfirmText"></p>
        </div>
        
        <form method="POST" action="admin.php">
            <input type="hidden" name="action" value="deleteCardinal">
            <input type="hidden" id="delete_cardinal_id" name="cardinal_id" value="">
            
            <div class="flex justify-end">
                <button type="button" class="mr-2 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onclick="closeDeleteModal()">
                    Annulla
                </button>
                <button type="submit" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Elimina
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Funzioni per il modal del cardinale
function openCardinalModal() {
    // Resetta il form
    document.getElementById('cardinalForm').reset();
    document.getElementById('cardinal_id').value = '';
    document.getElementById('cardinalModalTitle').innerText = 'Aggiungi Cardinale';
    
    // Mostra il modal
    document.getElementById('cardinalModal').classList.remove('hidden');
}

function closeCardinalModal() {
    document.getElementById('cardinalModal').classList.add('hidden');
}

function editCardinal(cardinal) {
    // Imposta il titolo del modal
    document.getElementById('cardinalModalTitle').innerText = 'Modifica Cardinale';
    
    // Imposta i valori nei campi del form
    document.getElementById('cardinal_id').value = cardinal.id;
    document.getElementById('name').value = cardinal.name;
    document.getElementById('age').value = cardinal.age || '';
    document.getElementById('nation').value = cardinal.nation || '';
    document.getElementById('continent').value = cardinal.continent || '';
    document.getElementById('created_by').value = cardinal.created_by || '';
    document.getElementById('voting_status').value = cardinal.voting_status || 'voting';
    document.getElementById('position').value = cardinal.position || '';
    document.getElementById('description').value = cardinal.description || '';
    document.getElementById('bookmaker_odds').value = cardinal.bookmaker_odds || '';
    document.getElementById('image_url').value = cardinal.image_url || '';
    
    // Mostra il modal
    document.getElementById('cardinalModal').classList.remove('hidden');
}

// Funzioni per il modal dell'utente
function openUserModal() {
    document.getElementById('userModal').classList.remove('hidden');
}

function closeUserModal() {
    document.getElementById('userModal').classList.add('hidden');
}

// Funzioni per il modal di eliminazione
function deleteCardinal(id, name) {
    document.getElementById('delete_cardinal_id').value = id;
    document.getElementById('deleteConfirmText').innerText = 'Sei sicuro di voler eliminare il cardinale "' + name + '"?';
    document.getElementById('deleteModal').classList.remove('hidden');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.add('hidden');
}

// Conferma prima di attivare/disattivare modalità conclave
document.addEventListener('DOMContentLoaded', function() {
    // Trova il form della modalità Conclave
    const conclaveForm = document.querySelector('form[action="admin.php"] input[name="action"][value="toggleConclave"]').closest('form');
    
    // Aggiungi event listener
    conclaveForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Previene il submit standard
        
        const isActive = <?php echo json_encode($conclave_mode_active); ?>;
        let message = '';
        
        if (isActive) {
            message = 'Sei sicuro di voler DISATTIVARE la modalità Conclave? Gli utenti potranno nuovamente piazzare e modificare scommesse.';
        } else {
            message = 'Sei sicuro di voler ATTIVARE la modalità Conclave? Questo bloccherà tutte le scommesse fino a nuova disattivazione.';
        }
        
        if (confirm(message)) {
            this.submit(); // Procedi con il submit solo se confermato
        }
    });
});
</script>

<?php
// Includi il footer
includeFooter();
?>