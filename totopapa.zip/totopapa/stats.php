<?php
// statistics.php – Pagina di statistiche completa (palette aggiornata)
// Rimuove la colonna "Grafico" dalla Classifica Completa
// Visualizza etichette interne nei grafici a torta e palette corretta per tutti i chart.

require_once 'config.php';
require_once 'header_footer.php';

// Redirect se non loggato
if (!isLoggedIn()) {
    redirect('login.php');
}

$db = getDbConnection();

// 1) Cardinali e loro scommesse
$stmt_cardinals = $db->query("
    SELECT
        c.*,
        (SELECT COUNT(b.id)   FROM bets b WHERE b.cardinal_id = c.id) AS total_bettors,
        (SELECT SUM(b.amount) FROM bets b WHERE b.cardinal_id = c.id) AS total_bet_amount
    FROM cardinals c
    ORDER BY total_bet_amount DESC
");
$cardinals = $stmt_cardinals->fetchAll(PDO::FETCH_ASSOC);

// Calcola massimo per normalizzare barre
$maxBet = 0;
foreach ($cardinals as $c) {
    $maxBet = max($maxBet, $c['total_bet_amount'] ?? 0);
}

// 2) Statistiche generali
$stmt_stats = $db->query("
    SELECT
        COUNT(DISTINCT user_id) AS total_bettors,
        SUM(amount)               AS total_amount,
        AVG(amount)               AS avg_bet,
        MAX(amount)               AS max_bet
    FROM bets
");
$stats = $stmt_stats->fetch(PDO::FETCH_ASSOC);

// 3) Statistiche per continente
$stmt_continent = $db->query("
    SELECT
        c.continent,
        COUNT(DISTINCT b.user_id) AS bettors,
        SUM(b.amount)            AS total_amount,
        COUNT(DISTINCT c.id)     AS cardinals_count
    FROM cardinals c
    LEFT JOIN bets b ON b.cardinal_id = c.id
    GROUP BY c.continent
    ORDER BY total_amount DESC
");
$continent_stats = $stmt_continent->fetchAll(PDO::FETCH_ASSOC);

// Dati per JS grafici continente
$continentNames     = array_column($continent_stats, 'continent');
$continentAmounts   = array_map(fn($c)=>(float)($c['total_amount'] ?? 0), $continent_stats);
$continentCardinals = array_map(fn($c)=>(int)  ($c['cardinals_count'] ?? 0), $continent_stats);
$continentColorMap  = [
    'Europa'           => '#ff930f',
    'Africa'           => '#ffb347',
    'America del Nord' => '#ff7f50',
    'America del Sud'  => '#ffd700',
    'Asia'             => '#ffa07a',
    'Oceania'          => '#ffcc33'
];
$continentColors = array_map(fn($n)=> $continentColorMap[$n] ?? '#ccc', $continentNames);

// 4) Scommesse utente
$stmt_user = $db->prepare("
    SELECT
        b.cardinal_id,
        b.amount,
        c.name        AS cardinal_name,
        c.image_url
    FROM bets b
    JOIN cardinals c ON c.id = b.cardinal_id
    WHERE b.user_id = :uid
    ORDER BY b.amount DESC
");
$stmt_user->execute([':uid' => $_SESSION['user_id']]);
$userBets = $stmt_user->fetchAll(PDO::FETCH_ASSOC);

$userTotalBet      = array_sum(array_column($userBets, 'amount'));
$userCardinalCount = count($userBets);

// Palette per Donut utente
$palette     = ['#ff930f','#ffb347','#ff7f50','#ffd700','#ffa07a','#ffcc33'];
$userLabels  = [];
$userSeries  = [];
$userColors  = [];
foreach ($userBets as $i => $b) {
    $userLabels[] = $b['cardinal_name'];
    $userSeries[] = (float)$b['amount'];
    $userColors[] = $palette[$i % count($palette)];
}

// 5) Scatter Quota vs Scommesse
$scatterData = array_map(fn($c)=>[
    'quota'   => (float)$c['bookmaker_odds'],
    'amount'  => (float)($c['total_bet_amount'] ?? 0),
    'bettors' => (int)  ($c['total_bettors']    ?? 0)
], $cardinals);

// 6) Progressione (top 5)
$top5            = array_slice($cardinals, 0, 5);
$progNames       = array_column($top5, 'name');
$progFinalValues = array_map(fn($c)=>(float)($c['total_bet_amount'] ?? 0), $top5);

// Includi header
includeHeader('Statistiche Scommesse Papali');
?>

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
<!-- ApexCharts & GSAP -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.1/ScrollTrigger.min.js"></script>

<style>
body { font-family:'Outfit',sans-serif; background:#f5f5f5; }
.page-title { color:#ff930f; position:relative; display:inline-block; }
.page-title::after {
  content:""; position:absolute; bottom:-5px; left:0; width:50px; height:3px;
  background:linear-gradient(to right,#ff930f,#ffcc33); border-radius:3px;
}
.data-card, .chart-container, .bars-list, table { margin-bottom:2rem; }

/* Bars-list */
.bars-list { max-width:1000px; margin:2rem auto; }
.bar-item {
  display:grid; grid-template-columns:200px 1fr 120px;
  align-items:center; gap:1rem; margin-bottom:1.5rem;
  opacity:0; transform:translateY(20px);
  animation:fadeInUp .8s ease-out forwards;
  animation-delay:calc(var(--i)*.1s);
}
.bar-item .name   { font-weight:600; color:#333; }
.bar-item .voters { font-size:.85rem; color:#666; margin-top:.2rem; }
.bar-wrapper { position:relative; width:100%; }
.bar-container {
  background:#e0e0e0; height:40px; border-radius:20px; overflow:hidden;
}
.bar {
  height:100%; width:0;
  background:linear-gradient(90deg,#ff930f 0%,#ffcc33 50%,#ff930f 100%);
  background-size:200% 100%; border-radius:20px;
  transition:width 1.5s ease-out; animation:gradientMove 4s linear infinite;
}
.cardinal-pin {
  position:absolute; top:50%; left:0;
  transform:translate(-50%,-50%);
  width:48px; height:48px; border-radius:50%;
  border:3px solid white; box-shadow:0 4px 12px rgba(0,0,0,.15);
  background:#fff; transition:transform .3s,left 1.5s;
}
.bar-item:hover .cardinal-pin { transform:translate(-50%,-50%) scale(1.1); }
.bar-item .value { font-weight:600; color:#333; margin-left:30px; }
@keyframes fadeInUp { to{opacity:1;transform:translateY(0);} }
@keyframes gradientMove {
  0%{background-position:0% 0;}50%{background-position:100% 0;}100%{background-position:0% 0;}
}
@media (max-width: 768px) {
  .bar-item {
    grid-template-columns: 1fr !important;
    grid-template-rows: auto auto auto;
  }

  .bar-item .value {
    margin-left: 0;
    text-align: left;
  }
}

</style>

<div class="mb-8">
  <h1 class="text-4xl font-bold page-title">Statistiche Scommesse Papali</h1>
  <p class="text-gray-600 text-lg">Analisi dettagliata delle scommesse per le Elezioni Papali 2025</p>
</div>

<!-- Statistiche Generali -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
  <?php
    $blocks = [
      ['fa-users','Scommettitori Totali',$stats['total_bettors'],'number'],
      ['fa-euro-sign','Importo Totale',$stats['total_amount'],'currency'],
      ['fa-chart-line','Media Scommessa',$stats['avg_bet'],'currency'],
      ['fa-trophy','Scommessa Massima',$stats['max_bet'],'currency']
    ];
    foreach($blocks as $i=>$b):
      [$icon,$title,$val,$fmt] = $b;
      $disp = $fmt==='currency'
        ? '€'.number_format($val,2,',','.')
        : number_format($val,0,',','.');
  ?>
  <div class="data-card p-6" style="opacity:0;transform:translateY(20px);animation:fadeInUp .8s forwards;animation-delay:<?= $i*.1 ?>s">
    <div class="flex items-center mb-4">
      <div class="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center mr-4">
        <i class="fas <?= $icon ?> text-[#ff930f] text-xl"></i>
      </div>
      <h3 class="text-lg font-semibold"><?= $title ?></h3>
    </div>
    <p class="text-3xl font-bold counter-value" data-value="<?= $val ?>" data-format="<?= $fmt ?>"><?= $disp ?></p>
  </div>
  <?php endforeach; ?>
</div>

<?php if($userCardinalCount>0): ?>
<!-- Statistiche Utente -->
<div class="mb-10">
  <h2 class="text-2xl font-bold mb-5">Le Tue Statistiche</h2>
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="chart-container p-6">
      <h3 class="text-xl font-semibold mb-4">Il tuo Contributo</h3>
      <div class="grid gap-4">
        <?php
          $us = [
            ['Cardinali scommessi',$userCardinalCount,'number'],
            ['Totale scommesso',$userTotalBet,'currency'],
            ['Saldo disponibile',$_SESSION['balance'],'currency']
          ];
          foreach($us as $v):
            [$lab,$val,$fmt] = $v;
            $disp = $fmt==='currency'
              ? '€'.number_format($val,2,',','.')
              : number_format($val,0,',','.');
        ?>
        <div class="bg-gray-50 p-4 rounded-lg">
          <p class="text-sm text-gray-600"><?= $lab ?></p>
          <p class="text-2xl font-bold text-[#ff930f]"><?= $disp ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="chart-container p-6">
      <h3 class="text-xl font-semibold mb-4">Distribuzione delle tue Scommesse</h3>
      <div id="userDonutChart" class="w-full h-80"></div>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Top 10 Cardinali Bars-list -->
<div class="mb-10">
  <h2 class="text-2xl font-bold mb-5">Top 10 Cardinali più scommessi</h2>
  <div class="bars-list">
    <?php foreach(array_slice($cardinals,0,10) as $i=>$c):
      $amt = (float)($c['total_bet_amount'] ?? 0);
      $pct = $maxBet>0?round($amt/$maxBet*100,2):0;
    ?>
    <div class="bar-item" style="--i:<?= $i ?>;">
      <div class="label">
        <p class="name"><?= htmlspecialchars($c['name']) ?></p>
        <p class="voters"><?= (int)$c['total_bettors'] ?> votanti</p>
      </div>
      <div class="bar-wrapper">
        <div class="bar-container">
          <div class="bar" data-pct="<?= $pct ?>"></div>
        </div>
        <img src="<?= htmlspecialchars($c['image_url']?:'https://via.placeholder.com/48') ?>"
             class="cardinal-pin" alt="" />
      </div>
      <div class="value">€<?= number_format($amt,2,',','.') ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Classifica Completa -->
<div class="mb-10">
  <h2 class="text-2xl font-bold mb-5">Classifica Completa</h2>
  <div class="bg-white rounded-2xl shadow-md p-6 overflow-auto">
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50">
        <tr>
          <th class="px-6 py-3 text-xs uppercase text-gray-500">#</th>
          <th class="px-6 py-3 text-xs uppercase text-gray-500">Cardinale</th>
          <th class="px-6 py-3 text-xs uppercase text-gray-500">Nazione</th>
          <th class="px-6 py-3 text-xs uppercase text-gray-500">Quota</th>
          <th class="px-6 py-3 text-xs uppercase text-gray-500">Scommettitori</th>
          <th class="px-6 py-3 text-xs uppercase text-gray-500">Totale</th>
        </tr>
      </thead>
      <tbody class="bg-white divide-y divide-gray-200">
        <?php foreach($cardinals as $i=>$c):
          $amt = (float)($c['total_bet_amount'] ?? 0);
        ?>
        <tr>
          <td class="px-6 py-4 text-sm font-medium"><?= $i+1 ?></td>
          <td class="px-6 py-4">
            <div class="flex items-center">
              <img src="<?= htmlspecialchars($c['image_url']?:'https://via.placeholder.com/40') ?>"
                   class="h-10 w-10 rounded-full" alt="" />
              <span class="ml-3"><?= htmlspecialchars($c['name']) ?></span>
            </div>
          </td>
          <td class="px-6 py-4 text-sm text-gray-500"><?= htmlspecialchars($c['nation']) ?></td>
          <td class="px-6 py-4 text-sm text-gray-500"><?= number_format($c['bookmaker_odds'],2,',','.') ?></td>
          <td class="px-6 py-4 text-sm text-gray-500"><?= (int)$c['total_bettors'] ?></td>
          <td class="px-6 py-4 text-sm text-[#ff930f]">€<?= number_format($amt,2,',','.') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Statistiche per Continente -->
<div class="mb-10">
  <h2 class="text-2xl font-bold mb-5">Scommesse per Continente</h2>
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="chart-container p-6">
      <h3 class="text-xl mb-4">Importi per Continente</h3>
      <div id="continentPieChart" class="w-full h-80"></div>
    </div>
    <div class="chart-container p-6">
      <h3 class="text-xl mb-4">Cardinali per Continente</h3>
      <div id="cardinalsPerContinent" class="w-full h-80"></div>
    </div>
  </div>
</div>

<!-- Quota vs Scommesse -->
<div class="mb-10">
  <h2 class="text-2xl font-bold mb-5">Quota vs Scommesse</h2>
  <div id="quotaVsBetChart" class="w-full h-96"></div>
</div>

<!-- Progressione Scommesse -->
<div class="mb-10">
  <h2 class="text-2xl font-bold mb-5">Progressione Scommesse (ultimi 30 giorni)</h2>
  <div id="progressionChart" class="w-full h-80"></div>
</div>

<script>
// Bars-list animation
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.bar-item').forEach((item,i) => {
    const bar = item.querySelector('.bar');
    const pin = item.querySelector('.cardinal-pin');
    const pct = parseFloat(bar.dataset.pct)||0;
    
    // Funzione per calcolare la posizione sicura del pin
    const setSafePosition = () => {
      bar.style.width = pct+'%';
      
      // Calcola la posizione sicura: non permettere che il pin superi i limiti del contenitore
      const containerWidth = item.querySelector('.bar-container').offsetWidth;
      const pinWidth = pin.offsetWidth;
      
      // Calcola i limiti minimi e massimi per mantenere il pin visibile
      const maxPct = 97; // Limita al 97% per mantenere visibile parte dell'immagine
      const minPct = 3;  // Minimo 3% per non farlo sparire a sinistra
      
      // Usa la percentuale originale ma limitata da min e max
      const safePct = Math.max(minPct, Math.min(pct, maxPct));
      pin.style.left = safePct+'%';
    };
    
    // Imposta la posizione con un leggero ritardo per l'animazione
    setTimeout(setSafePosition, 200+i*100);
    
    // Ricalcola le posizioni quando la finestra viene ridimensionata
    window.addEventListener('resize', setSafePosition);
  });
});

// Counter animation
gsap.registerPlugin(ScrollTrigger);
function animateCounters(){
  document.querySelectorAll('.counter-value').forEach(el=>{
    const target = parseFloat(el.dataset.value);
    const fmt    = el.dataset.format;
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(e.isIntersecting){
          const start=0, dur= target>1000?2500:2000;
          const t0=performance.now();
          (function upd(now){
            const p=Math.min((now-t0)/dur,1);
            const v=start+(target-start)*(1-Math.pow(1-p,4));
            el.textContent = fmt==='currency'
              ? '€'+v.toLocaleString('it-IT',{minimumFractionDigits:2})
              : Math.floor(v).toLocaleString('it-IT');
            if(p<1) requestAnimationFrame(upd);
          })(t0);
          obs.disconnect();
        }
      });
    },{threshold:0.5});
    obs.observe(el);
  });
}

// Init ApexCharts
const continentNamesJS     = <?= json_encode($continentNames) ?>;
const continentAmountsJS   = <?= json_encode($continentAmounts) ?>;
const continentCardinalsJS = <?= json_encode($continentCardinals) ?>;
const continentColorsJS    = <?= json_encode($continentColors) ?>;
<?php if($userCardinalCount>0): ?>
const userLabelsJS = <?= json_encode($userLabels) ?>;
const userSeriesJS = <?= json_encode($userSeries) ?>;
const userColorsJS = <?= json_encode($userColors) ?>;
<?php endif; ?>
const scatterJS = <?= json_encode($scatterData) ?>;
const progNamesJS = <?= json_encode($progNames) ?>;
const progValsJS  = <?= json_encode($progFinalValues) ?>;

function initCharts(){
  // Opzioni responsive comuni per i grafici
  const getResponsiveOptions = (type) => {
    return [{
      breakpoint: 768,
      options: {
        chart: { height: 300 },
        legend: { position: 'bottom', fontSize: '12px' },
        dataLabels: { 
          enabled: type === 'pie' || type === 'donut',
          style: { fontSize: '10px' }
        }
      }
    }];
  };

  // Pie Continent
  new ApexCharts(
    document.getElementById('continentPieChart'),
    {
      series: continentAmountsJS,
      chart:{type:'pie',height:360},
      labels:continentNamesJS,
      colors:continentColorsJS,
      plotOptions:{ pie:{ dataLabels:{ offset:0 } } },
      dataLabels:{ enabled:true, style:{fontSize:'14px'} },
      tooltip:{ y:{formatter:v=>'€'+v.toLocaleString('it-IT',{minimumFractionDigits:2})} },
      responsive: getResponsiveOptions('pie')
    }
  ).render();

  // Bar Continent
  new ApexCharts(
    document.getElementById('cardinalsPerContinent'),
    {
      series:[{name:'Cardinali',data:continentCardinalsJS}],
      chart:{type:'bar',height:360},
      colors:['#ffcc33'],
      plotOptions:{ bar:{borderRadius:8,columnWidth:'60%'} },
      xaxis:{ categories:continentNamesJS },
      responsive: getResponsiveOptions('bar')
    }
  ).render();

  <?php if($userCardinalCount>0): ?>
  // Donut Utente
  new ApexCharts(
    document.getElementById('userDonutChart'),
    {
      series:userSeriesJS,
      chart:{type:'donut',height:360},
      labels:userLabelsJS,
      colors:userColorsJS,
      plotOptions:{ pie:{ donut:{ 
        size:'60%', 
        labels:{ 
          show:true, 
          total:{ 
            show:true, 
            label:'Totale', 
            formatter:w=>'€'+w.globals.seriesTotals.reduce((a,b)=>a+b,0).toLocaleString('it-IT',{minimumFractionDigits:2}) 
          } 
        } 
      } } },
      tooltip:{ y:{formatter:v=>'€'+v.toLocaleString('it-IT',{minimumFractionDigits:2})} },
      responsive: getResponsiveOptions('donut')
    }
  ).render();
  <?php endif; ?>

  // Quota vs Scommesse
  new ApexCharts(
    document.getElementById('quotaVsBetChart'),
    {
      series:[
        {name:'€ scommessi',type:'line',data:scatterJS.map(d=>d.amount)},
        {name:'# bettors',   type:'column',data:scatterJS.map(d=>d.bettors)}
      ],
      chart:{type:'line',height:360,stacked:false},
      stroke:{curve:'smooth',width:[3,0]},
      colors:['#ff930f','#ffcc33'],
      xaxis:{ type:'numeric', categories:scatterJS.map(d=>d.quota), title:{text:'Quota'} },
      yaxis:[{title:{text:'€ scommessi'}},{opposite:true,title:{text:'# scommettitori'}}],
      tooltip:{ shared:true, intersect:false },
      responsive: getResponsiveOptions('mixed')
    }
  ).render();

  // Progressione Scommesse
  const progSeries = progNamesJS.map((name,i)=>{
    let curr = progValsJS[i]*0.1, data=[];
    for(let d=0;d<30;d++){
      curr = Math.min(curr*(1+Math.random()*0.15),progValsJS[i]);
      data.push({ x: Date.now() - (29-d)*86400000, y:Math.round(curr) });
    }
    return { name, data };
  });
  new ApexCharts(
    document.getElementById('progressionChart'),
    {
      series:progSeries,
      chart:{type:'area',height:320,stacked:false},
      colors:['#ff930f','#ffb347','#ff7f50','#ffd700','#ffa07a'],
      stroke:{curve:'smooth',width:2},
      fill:{ type:'gradient', gradient:{ opacityFrom:0.6, opacityTo:0.1 } },
      xaxis:{type:'datetime',labels:{format:'dd/MM'}},
      yaxis:{labels:{formatter:v=>'€'+v}},
      responsive: getResponsiveOptions('area')
    }
  ).render();
}

document.addEventListener('DOMContentLoaded',()=>{
  animateCounters();
  initCharts();
});
</script>

<?php includeFooter(); ?>
