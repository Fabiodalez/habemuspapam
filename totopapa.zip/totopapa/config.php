<?php
// config.php - File di configurazione

// --------------------------------------
// 1) Durata della sessione in secondi (5 ore)
$lifetime = 5 * 3600; // 5 ore = 18.000 secondi

// Imposta il cookie di sessione
session_set_cookie_params([
    'lifetime' => $lifetime,
    'path'     => '/',                 // valido in tutta l'app
    'domain'   => $_SERVER['HTTP_HOST'], // dominio corrente
    'secure'   => true,                // solo HTTPS (metti false in dev locale se non usi HTTPS)
    'httponly' => true,                // non accessibile da JavaScript
    'samesite' => 'Lax',               // oppure 'Strict' se vuoi più rigidità
]);

// Estendi la garbage‐collection sul server
ini_set('session.gc_maxlifetime', $lifetime);

// --------------------------------------
// 2) Avvia la sessione (dopo aver configurato i parametri)
session_start();

// --------------------------------------
// Configurazione del database
define('DB_PATH', __DIR__ . '/database/papalelections.db');

// Controlla e crea la directory database
$dbDir = dirname(DB_PATH);
if (!file_exists($dbDir)) {
    if (!mkdir($dbDir, 0777, true)) {
        die("Errore: Impossibile creare la directory $dbDir");
    }
    chmod($dbDir, 0777);
}

// Impostazioni applicazione
define('APP_NAME', 'PapalBet');
define('APP_URL', '');
define('DEFAULT_BALANCE', 1000.00);

// Connessione al database SQLite
function getDbConnection() {
    try {
        $dbDir = dirname(DB_PATH);
        if (!file_exists($dbDir)) {
            if (!mkdir($dbDir, 0777, true)) {
                die("Errore: Impossibile creare la directory $dbDir");
            }
            chmod($dbDir, 0777);
        }
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch (PDOException $e) {
        die('Errore di connessione al database: ' . $e->getMessage());
    }
}

// Inizializzazione del database (se non esiste)
function initializeDatabase() {
    $dbDir = dirname(DB_PATH);
    if (!file_exists($dbDir)) {
        if (!mkdir($dbDir, 0777, true)) {
            die("Errore: Impossibile creare la directory $dbDir");
        }
        chmod($dbDir, 0777);
    }
    try {
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        // Tabella users
        $db->exec('
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                balance DECIMAL(10,2) DEFAULT 1000.00,
                is_admin INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ');
        // Tabella cardinals
        $db->exec('
            CREATE TABLE IF NOT EXISTS cardinals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                age INTEGER,
                nation TEXT,
                continent TEXT,
                created_by TEXT,
                voting_status TEXT,
                position TEXT,
                description TEXT,
                bookmaker_odds DECIMAL(10,2) DEFAULT 0.00,
                image_url TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ');
        // Tabella bets
        $db->exec('
            CREATE TABLE IF NOT EXISTS bets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                cardinal_id INTEGER,
                amount DECIMAL(10,2) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (cardinal_id) REFERENCES cardinals(id)
            )
        ');
        // Utente admin di default
        $stmt = $db->query("SELECT COUNT(*) FROM users");
        if ($stmt->fetchColumn() == 0) {
            $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
            $db->exec("
                INSERT INTO users (username, password, balance, is_admin) 
                VALUES ('admin', '$password_hash', 1000.00, 1)
            ");
        }
        return $db;
    } catch (PDOException $e) {
        die('Errore di inizializzazione del database: ' . $e->getMessage());
    }
}

// Funzioni di utilità
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

function redirect($path) {
    header("Location: $path");
    exit;
}

// Inizializza il database
initializeDatabase();
