<?php
// index.php - Pagina principale con lista cardinali
require_once 'config.php';
require_once 'header_footer.php';

// Controlla se l'utente è loggato
if (!isLoggedIn()) {
    redirect('login.php');
}

// Ottieni la connessione al database
$db = getDbConnection();

// --- NUOVO: Controlla lo stato della modalità Conclave ---
$stmt_settings = $db->query("SELECT value FROM settings WHERE name = 'conclave'");
$setting = $stmt_settings->fetch(PDO::FETCH_ASSOC);
// Se l'impostazione non esiste o è diversa da '1', la modalità conclave è disattiva.
$conclave_mode_active = ($setting && $setting['value'] === '1');
// --- FINE NUOVO ---

// Recupera tutti i cardinali dal database
$stmt_cardinals = $db->query('
    SELECT
        c.*,
        (SELECT COUNT(b.id) FROM bets b WHERE b.cardinal_id = c.id) AS total_bettors,
        (SELECT SUM(b.amount) FROM bets b WHERE b.cardinal_id = c.id) AS total_bet_amount
    FROM
        cardinals c
    ORDER BY
        c.name ASC
');
$cardinals = $stmt_cardinals->fetchAll(PDO::FETCH_ASSOC);

// Recupera le scommesse dell'utente corrente
$stmt_user_bets = $db->prepare('
    SELECT cardinal_id, id, amount
    FROM bets
    WHERE user_id = :user_id
');
$stmt_user_bets->bindParam(':user_id', $_SESSION['user_id']);
$stmt_user_bets->execute();
$userBets = [];
$userBetsIds = [];
while ($bet = $stmt_user_bets->fetch(PDO::FETCH_ASSOC)) {
    $userBets[$bet['cardinal_id']] = $bet['amount'];
    $userBetsIds[$bet['cardinal_id']] = $bet['id'];
}

// Gestisci la richiesta di piazzare o eliminare una scommessa
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- NUOVO: Controlla se la modalità Conclave è attiva PRIMA di processare le scommesse ---
    if ($conclave_mode_active) {
        $message = 'La modalità Conclave è attiva. Non è possibile piazzare, modificare o eliminare scommesse in questo momento.';
        $messageType = 'warning'; // Usiamo 'warning' per distinguerlo da errori reali
    } else {
        // --- LOGICA ORIGINALE (solo se il conclave NON è attivo) ---

        // Gestione della scommessa (piazzamento/aggiornamento)
        if (isset($_POST['bet_amount'], $_POST['cardinal_id'])) {
            $cardinalId = (int)$_POST['cardinal_id'];
            $betAmount = (float)$_POST['bet_amount'];
            $userId = $_SESSION['user_id'];

            // Verifica che l'importo sia valido
            if ($betAmount <= 0) {
                $message = 'L\'importo della scommessa deve essere positivo';
                $messageType = 'error';
            }
            // Verifica che l'utente abbia abbastanza saldo
            elseif ($betAmount > $_SESSION['balance']) {
                $message = 'Saldo insufficiente per piazzare questa scommessa';
                $messageType = 'error';
            }
            // Verifica che il cardinale esista
            else {
                $stmt_check_cardinal = $db->prepare('SELECT id FROM cardinals WHERE id = :id');
                $stmt_check_cardinal->bindParam(':id', $cardinalId);
                $stmt_check_cardinal->execute();

                if (!$stmt_check_cardinal->fetch()) {
                    $message = 'Cardinale non trovato';
                    $messageType = 'error';
                } else {
                    // Verifica se l'utente ha già piazzato una scommessa su questo cardinale
                    $stmt_check_bet = $db->prepare('SELECT id, amount FROM bets WHERE user_id = :user_id AND cardinal_id = :cardinal_id');
                    $stmt_check_bet->bindParam(':user_id', $userId);
                    $stmt_check_bet->bindParam(':cardinal_id', $cardinalId);
                    $stmt_check_bet->execute();
                    $existingBet = $stmt_check_bet->fetch(PDO::FETCH_ASSOC);

                    $db->beginTransaction();

                    try {
                        if ($existingBet) {
                            // Aggiorna la scommessa esistente
                            $newAmount = $betAmount;
                            $amountDifference = $newAmount - $existingBet['amount'];

                            // Verifica che l'utente abbia abbastanza saldo per l'aggiornamento
                            // NB: Controlliamo solo se l'importo aumenta
                            if ($amountDifference > 0 && $amountDifference > $_SESSION['balance']) {
                                throw new Exception('Saldo insufficiente per aggiornare la scommessa');
                            }

                            // Aggiorna l'importo della scommessa
                            $stmt_update_bet = $db->prepare('UPDATE bets SET amount = :amount WHERE id = :id');
                            $stmt_update_bet->bindParam(':amount', $newAmount);
                            $stmt_update_bet->bindParam(':id', $existingBet['id']);
                            $stmt_update_bet->execute();

                            // Aggiorna il saldo dell'utente
                            $newBalance = $_SESSION['balance'] - $amountDifference;
                            $stmt_update_balance = $db->prepare('UPDATE users SET balance = :balance WHERE id = :id');
                            $stmt_update_balance->bindParam(':balance', $newBalance);
                            $stmt_update_balance->bindParam(':id', $userId);
                            $stmt_update_balance->execute();

                            // Aggiorna la sessione
                            $_SESSION['balance'] = $newBalance;

                            $message = 'Scommessa aggiornata con successo';
                            $messageType = 'success';
                        } else {
                             // Verifica saldo (anche se già fatto prima, doppia sicurezza)
                             if ($betAmount > $_SESSION['balance']) {
                                throw new Exception('Saldo insufficiente per piazzare questa scommessa');
                             }
                            // Inserisce una nuova scommessa
                            $stmt_insert_bet = $db->prepare('INSERT INTO bets (user_id, cardinal_id, amount) VALUES (:user_id, :cardinal_id, :amount)');
                            $stmt_insert_bet->bindParam(':user_id', $userId);
                            $stmt_insert_bet->bindParam(':cardinal_id', $cardinalId);
                            $stmt_insert_bet->bindParam(':amount', $betAmount);
                            $stmt_insert_bet->execute();
                            $newBetId = $db->lastInsertId(); // Ottieni l'ID della nuova scommessa

                            // Aggiorna il saldo dell'utente
                            $newBalance = $_SESSION['balance'] - $betAmount;
                            $stmt_update_balance = $db->prepare('UPDATE users SET balance = :balance WHERE id = :id');
                            $stmt_update_balance->bindParam(':balance', $newBalance);
                            $stmt_update_balance->bindParam(':id', $userId);
                            $stmt_update_balance->execute();

                            // Aggiorna la sessione
                            $_SESSION['balance'] = $newBalance;

                            // Aggiorna l'array locale delle scommesse utente
                            $userBets[$cardinalId] = $betAmount;
                            $userBetsIds[$cardinalId] = $newBetId;

                            $message = 'Scommessa piazzata con successo';
                            $messageType = 'success';
                        }

                        $db->commit();

                        // Ricarica le scommesse dell'utente DOPO il commit per essere sicuri
                        $stmt_reload_bets = $db->prepare('SELECT cardinal_id, id, amount FROM bets WHERE user_id = :user_id');
                        $stmt_reload_bets->bindParam(':user_id', $_SESSION['user_id']);
                        $stmt_reload_bets->execute();
                        $userBets = [];
                        $userBetsIds = [];
                        while ($bet = $stmt_reload_bets->fetch(PDO::FETCH_ASSOC)) {
                            $userBets[$bet['cardinal_id']] = $bet['amount'];
                            $userBetsIds[$bet['cardinal_id']] = $bet['id'];
                        }

                    } catch (Exception $e) {
                        $db->rollBack();
                        $message = $e->getMessage();
                        $messageType = 'error';
                    }
                }
            }
        }
        // Gestione eliminazione scommessa
        elseif (isset($_POST['action']) && $_POST['action'] === 'deleteBet' && isset($_POST['bet_id'])) {
            $betId = (int)$_POST['bet_id'];
            $userId = $_SESSION['user_id'];

            $db->beginTransaction(); // Inizia la transazione

            try {
                // Verifica che la scommessa esista e appartenga all'utente
                $stmt_find_bet = $db->prepare('SELECT id, amount, cardinal_id FROM bets WHERE id = :id AND user_id = :user_id');
                $stmt_find_bet->bindParam(':id', $betId);
                $stmt_find_bet->bindParam(':user_id', $userId);
                $stmt_find_bet->execute();
                $bet = $stmt_find_bet->fetch(PDO::FETCH_ASSOC);

                if ($bet) {
                    // Rimuovi la scommessa
                    $stmt_delete_bet = $db->prepare('DELETE FROM bets WHERE id = :id');
                    $stmt_delete_bet->bindParam(':id', $betId);
                    $stmt_delete_bet->execute();

                    // Aggiorna il saldo dell'utente (restituisci l'importo)
                    $newBalance = $_SESSION['balance'] + $bet['amount'];
                    $stmt_update_balance = $db->prepare('UPDATE users SET balance = :balance WHERE id = :id');
                    $stmt_update_balance->bindParam(':balance', $newBalance);
                    $stmt_update_balance->bindParam(':id', $userId);
                    $stmt_update_balance->execute();

                    // Aggiorna la sessione
                    $_SESSION['balance'] = $newBalance;

                    // Rimuovi la scommessa dall'array locale
                    unset($userBets[$bet['cardinal_id']]);
                    unset($userBetsIds[$bet['cardinal_id']]);

                    $db->commit(); // Conferma le modifiche

                    $message = 'Scommessa eliminata con successo';
                    $messageType = 'success';
                } else {
                    $db->rollBack(); // Annulla se la scommessa non è stata trovata
                    $message = 'Scommessa non trovata o non appartenente all\'utente';
                    $messageType = 'error';
                }
            } catch (Exception $e) {
                $db->rollBack(); // Annulla in caso di errore
                $message = 'Errore durante l\'eliminazione della scommessa: ' . $e->getMessage();
                $messageType = 'error';
            }
        }
        // --- FINE LOGICA ORIGINALE ---
    }
     // --- FINE NUOVO CHECK CONCLAVE ---
}

// Includi l'header
includeHeader('Scommesse Papali');
?>

<!-- Google Font Outfit -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Outfit', sans-serif;
        background-color: #f5f5f5;
    }

    .cardinal-card {
        position: relative;
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        overflow: hidden;
        border: 1px solid #eee;
    }

    .cardinal-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }

    .cardinal-image {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        overflow: hidden;
        border: 4px solid white;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        margin: 0 auto;
        position: relative;
        z-index: 2;
        background-color: #f0f2f5;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .cardinal-card::before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 120px;
        background: linear-gradient(135deg, #ff930f, #ffcc33);
        border-radius: 20px 20px 0 0;
        z-index: 1;
    }

    .gradient-btn {
        background: linear-gradient(to top, #ff930f, #ffcc33);
        color: white;
        transition: all 0.3s ease;
        border: none;
        position: relative;
        overflow: hidden;
        z-index: 1;
    }

    .gradient-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(255, 147, 15, 0.4);
    }

    .gradient-btn::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(to bottom, #ff930f, #ffcc33);
        opacity: 0;
        z-index: -1;
        transition: opacity 0.3s ease;
    }

    .gradient-btn:hover::after {
        opacity: 1;
    }

    /* --- NUOVO: Stile per bottone disabilitato in Conclave Mode --- */
    .conclave-disabled-btn {
        background: #a0aec0; /* Grigio */
        color: #e2e8f0; /* Grigio chiaro */
        cursor: not-allowed;
        box-shadow: none;
    }
     .conclave-disabled-btn:hover {
         transform: none;
         box-shadow: none;
         background: #a0aec0; /* Mantiene lo stesso grigio */
     }
    /* --- FINE NUOVO --- */


    .stats-box {
        cursor: pointer;
        transition: all 0.3s ease;
        border-radius: 10px;
        padding: 8px;
    }

    .stats-box:hover {
        background-color: #fff8e8;
    }

    .modal-content {
        border-radius: 20px;
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }

    .badge-bet {
        background: linear-gradient(to right, #ff930f, #ffcc33);
        color: white;
        border-radius: 50px;
        padding: 5px 15px;
        font-weight: 600;
        font-size: 0.875rem;
        display: inline-flex;
        align-items: center;
        margin-bottom: 12px;
    }

    .badge-bet i {
        margin-right: 5px;
    }

    .page-title {
        color: #ff930f;
        position: relative;
        display: inline-block;
    }

    .page-title::after {
        content: "";
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 50px;
        height: 3px;
        background: linear-gradient(to right, #ff930f, #ffcc33);
        border-radius: 3px;
    }

    /* Animazioni */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .animate-fadeIn {
        animation: fadeIn 0.5s ease forwards;
    }

    .quote-box {
        background: linear-gradient(to right, rgba(255, 147, 15, 0.1), rgba(255, 204, 51, 0.1));
        border-left: 4px solid #ff930f;
        padding: 10px 15px;
        border-radius: 0 10px 10px 0;
    }
</style>

<div class="mb-8 animate-fadeIn">
    <h1 class="text-4xl font-bold mb-3 page-title">Elezioni Papali 2025</h1>
    <p class="text-gray-600 text-lg">
        Piazza le tue scommesse sui cardinali papabili e segui le elezioni in tempo reale
    </p>

    <!-- Pulsante Statistiche -->
    <a href="stats.php"
       class="gradient-btn inline-block mt-4 px-4 py-2 rounded-full font-medium transition-all">
        <i class="fas fa-chart-bar mr-2"></i>
        Statistiche
    </a>
</div>



<?php // --- NUOVO: Banner Modalità Conclave --- ?>
<?php if ($conclave_mode_active): ?>
<div class="mb-6 p-4 rounded-lg shadow-md bg-yellow-100 text-yellow-800 border-l-4 border-yellow-500 animate-fadeIn">
    <div class="flex items-center">
        <div class="flex-shrink-0">
            <i class="fas fa-church text-yellow-600 mr-3 fa-lg"></i>
        </div>
        <div>
            <h4 class="font-bold text-lg">Modalità Conclave Attiva</h4>
            <p>Le scommesse sono temporaneamente sospese durante il Conclave.</p>
        </div>
    </div>
</div>
<?php endif; ?>
<?php // --- FINE NUOVO --- ?>


<?php if ($message): ?>
    <div class="mb-6 p-4 rounded-lg shadow-md <?php
        // Aggiungi stile per il warning del conclave
        switch ($messageType) {
            case 'error': echo 'bg-red-100 text-red-700 border-l-4 border-red-500'; break;
            case 'success': echo 'bg-green-100 text-green-700 border-l-4 border-green-500'; break;
            case 'warning': echo 'bg-yellow-100 text-yellow-700 border-l-4 border-yellow-500'; break; // Stile per conclave
            default: echo 'bg-blue-100 text-blue-700 border-l-4 border-blue-500'; // Fallback
        }
     ?> animate-fadeIn">
        <div class="flex items-center">
            <div class="flex-shrink-0">
                <?php
                 switch ($messageType) {
                    case 'error': echo '<i class="fas fa-exclamation-circle text-red-500 mr-2"></i>'; break;
                    case 'success': echo '<i class="fas fa-check-circle text-green-500 mr-2"></i>'; break;
                    case 'warning': echo '<i class="fas fa-exclamation-triangle text-yellow-500 mr-2"></i>'; break; // Icona per conclave
                    default: echo '<i class="fas fa-info-circle text-blue-500 mr-2"></i>'; // Fallback
                 }
                ?>
            </div>
            <div>
                <?php echo htmlspecialchars($message); // Usa htmlspecialchars per sicurezza ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Riepilogo scommesse dell'utente -->
<?php
$totalUserBets = count($userBets);
$totalAmountBet = array_sum($userBets);
?>

<?php if ($totalUserBets > 0): ?>
<div class="mb-8 bg-white rounded-lg shadow-md p-6 animate-fadeIn">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold text-gray-800">Le tue scommesse</h2>
        <button onclick="showUserBetsModal()" class="text-sm text-[#ff930f] hover:underline font-medium">
            Visualizza dettagli <i class="fas fa-arrow-right ml-1"></i>
        </button>
    </div>

    <div class="flex flex-wrap gap-4">
        <div class="flex-1 bg-gray-50 rounded-lg p-4">
            <p class="text-sm text-gray-600 mb-1">Cardinali scommessi</p>
            <p class="text-2xl font-bold text-[#ff930f]"><?php echo $totalUserBets; ?></p>
        </div>

        <div class="flex-1 bg-gray-50 rounded-lg p-4">
            <p class="text-sm text-gray-600 mb-1">Totale scommesso</p>
            <p class="text-2xl font-bold text-[#ff930f]">€<?php echo number_format($totalAmountBet, 2, ',', '.'); ?></p>
        </div>

        <div class="flex-1 bg-gray-50 rounded-lg p-4">
            <p class="text-sm text-gray-600 mb-1">Saldo disponibile</p>
            <p class="text-2xl font-bold text-[#ff930f]">€<?php echo number_format($_SESSION['balance'], 2, ',', '.'); ?></p>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Griglia di cardinali -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    <?php $loop_index = 0; // Inizializza indice per animazione ?>
    <?php foreach ($cardinals as $cardinal): ?>
    <div class="cardinal-card p-6 animate-fadeIn" style="animation-delay: <?php echo $loop_index * 0.05; ?>s;">
        <div class="cardinal-image">
            <?php if (!empty($cardinal['image_url'])): ?>
                <img src="<?php echo htmlspecialchars($cardinal['image_url']); ?>" alt="<?php echo htmlspecialchars($cardinal['name']); ?>" class="w-full h-full object-cover">
            <?php else: ?>
                <svg fill="#000000" xml:space="preserve" viewBox="0 0 64 64" height="70px" width="70px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" id="Layer_1" version="1.0">
                    <g><path d="M18,12c0-5.522,4.478-10,10-10h8c5.522,0,10,4.478,10,10v7c0-3.313-2.687-6-6-6h-6c-2.209,0-4-1.791-4-4c0-0.553-0.447-1-1-1s-1,0.447-1,1c0,2.209-1.791,4-4,4c-3.313,0-6,2.687-6,6V12z" fill="#506C7F"></path><path d="M62,60c0,1.104-0.896,2-2,2H4c-1.104,0-2-0.896-2-2v-8c0-1.104,0.447-2.104,1.172-2.828l-0.004-0.004c4.148-3.343,8.896-5.964,14.046-7.714C20.869,45.467,26.117,48,31.973,48c5.862,0,11.115-2.538,14.771-6.56c5.167,1.75,9.929,4.376,14.089,7.728l-0.004,0.004C61.553,49.896,62,50.896,62,52V60z" fill="#7d988a"></path></g>
                </svg>
            <?php endif; ?>
        </div>

        <div class="mt-8">
            <h2 class="text-xl font-bold text-gray-800 mb-1"><?php echo htmlspecialchars($cardinal['name']); ?></h2>
            <p class="text-gray-600 text-sm mb-3">
                <span class="font-medium"><?php echo htmlspecialchars($cardinal['nation']); ?></span>
                (<?php echo htmlspecialchars($cardinal['continent']); ?>)
            </p>

            <div class="grid grid-cols-2 gap-3 mb-4 text-sm">
                <div>
                    <span class="font-medium text-gray-700">Età:</span>
                    <span class="text-gray-600"><?php echo $cardinal['age']; ?> anni</span>
                </div>

                <div>
                    <span class="font-medium text-gray-700">Creato da:</span>
                    <span class="text-gray-600"><?php echo htmlspecialchars($cardinal['created_by']); ?></span>
                </div>

                <div>
                    <span class="font-medium text-gray-700">Votante:</span>
                    <span class="text-gray-600"><?php echo $cardinal['voting_status'] === 'voting' ? 'Sì' : 'No'; ?></span>
                </div>

                <div>
                    <span class="font-medium text-gray-700">Posizione:</span>
                    <span class="text-gray-600"><?php echo htmlspecialchars($cardinal['position']); ?></span>
                </div>
            </div>

            <?php if (!empty($cardinal['description'])): ?>
            <div class="mb-4">
                <p class="text-gray-700 text-sm"><?php echo nl2br(htmlspecialchars($cardinal['description'])); // Usa nl2br per i ritorni a capo ?></p>
            </div>
            <?php endif; ?>

            <div class="mb-4 mt-4 pt-4 border-t border-gray-200">
                <div class="quote-box">
                    <p class="font-bold text-gray-800">Quota: <?php echo number_format($cardinal['bookmaker_odds'], 2, ',', '.'); ?></p>
                </div>
            </div>

            <div class="mb-4 flex justify-between text-sm">
                 <div class="stats-box bg-gray-50 px-3 py-2 rounded flex-1 mr-1 text-center" onclick="showBettorsModal(<?php echo $cardinal['id']; ?>, '<?php echo addslashes(htmlspecialchars($cardinal['name'])); ?>')">
                    <span class="font-medium text-gray-700 block text-xs">Scommettitori</span>
                    <span class="text-[#ff930f] font-semibold block text-lg"><?php echo (int)$cardinal['total_bettors']; ?></span>
                </div>

                <div class="stats-box bg-gray-50 px-3 py-2 rounded flex-1 ml-1 text-center" onclick="showBettorsModal(<?php echo $cardinal['id']; ?>, '<?php echo addslashes(htmlspecialchars($cardinal['name'])); ?>')">
                    <span class="font-medium text-gray-700 block text-xs">Totale Scommesso</span>
                    <span class="text-[#ff930f] font-semibold block text-lg">€<?php echo number_format($cardinal['total_bet_amount'] ?? 0, 2, ',', '.'); ?></span>
                </div>
            </div>

            <?php
            // Controlla se l'utente ha già piazzato una scommessa su questo cardinale
            $hasUserBet = isset($userBets[$cardinal['id']]);
            $userBetAmount = $hasUserBet ? $userBets[$cardinal['id']] : 0;
            $userBetId = $hasUserBet ? $userBetsIds[$cardinal['id']] : 0;
            ?>

            <div class="mt-6">
                <?php // --- MODIFICATO: Mostra badge scommessa con/senza bottone elimina --- ?>
                <?php if ($hasUserBet): ?>
                    <div class="badge-bet mb-3 flex justify-between w-full">
                        <span><i class="fas fa-coins"></i> €<?php echo number_format($userBetAmount, 2, ',', '.'); ?></span>
                        <?php if (!$conclave_mode_active): // Mostra bottone elimina solo se non è conclave ?>
                            <button onclick="openDeleteBetModal(<?php echo $userBetId; ?>, '<?php echo addslashes(htmlspecialchars($cardinal['name'])); ?>', <?php echo $userBetAmount; ?>)" class="text-white hover:text-red-100 ml-2">
                                <i class="fas fa-times-circle"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php // --- MODIFICATO: Bottone scommessa/conclave --- ?>
                <button type="button"
                        class="w-full py-3 px-4 rounded-lg font-bold text-white flex items-center justify-center
                               <?php echo $conclave_mode_active ? 'conclave-disabled-btn' : 'gradient-btn'; ?>"
                        <?php if ($conclave_mode_active): ?>
                            disabled title="Le scommesse sono sospese durante il Conclave"
                        <?php else: ?>
                            onclick="openBetModal(<?php echo $cardinal['id']; ?>, '<?php echo addslashes(htmlspecialchars($cardinal['name'])); ?>', <?php echo $userBetAmount; ?>)"
                        <?php endif; ?>>

                    <?php if ($conclave_mode_active): ?>
                        <i class="fas fa-lock mr-2"></i> Modalità Conclave
                    <?php else: ?>
                        <i class="fas fa-coins mr-2"></i> <?php echo $hasUserBet ? 'Modifica scommessa' : 'Piazza scommessa'; ?>
                    <?php endif; ?>
                </button>
                 <?php // --- FINE MODIFICA --- ?>
            </div>
        </div>
    </div>
    <?php $loop_index++; // Incrementa indice per animazione ?>
    <?php endforeach; ?>
</div>

<!-- Modal per piazzare la scommessa -->
<div id="betModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-2xl shadow-lg w-full max-w-md modal-content">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-gray-800" id="modalTitle">Piazza una scommessa</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" onclick="closeBetModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <form id="betForm" method="POST" action="index.php"> <?php /* Action rimane index.php, il JS intercetta */ ?>
            <input type="hidden" id="cardinal_id" name="cardinal_id" value="">

            <div class="mb-6 bg-gray-50 p-4 rounded-lg">
                <div class="flex justify-between">
                    <p class="text-gray-600">Saldo disponibile:</p>
                    <p class="font-semibold text-[#ff930f]">€<span id="userBalance"><?php echo number_format($_SESSION['balance'], 2, ',', '.'); ?></span></p>
                </div>
            </div>

            <div class="mb-6">
                <label for="bet_amount" class="block text-gray-700 text-sm font-bold mb-2">
                    Importo della scommessa (€)
                </label>
                <input type="number"
                       id="bet_amount"
                       name="bet_amount"
                       step="0.01"
                       min="0.01"
                       max="<?php echo $_SESSION['balance']; ?>"
                       class="shadow appearance-none border border-gray-300 rounded-lg w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-[#ff930f] focus:border-transparent"
                       required
                       <?php echo $conclave_mode_active ? 'disabled' : ''; // Disabilita input se in conclave ?>
                       >
                <p class="text-sm text-gray-500 mt-2">Inserisci l'importo che vuoi scommettere per questo cardinale.</p>
                 <?php if ($conclave_mode_active): ?>
                    <p class="text-sm text-yellow-600 mt-1"><i class="fas fa-lock"></i> Le scommesse sono chiuse.</p>
                 <?php endif; ?>
            </div>

            <div class="flex justify-end">
                <button type="button" class="mr-3 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-3 px-6 rounded-lg focus:outline-none focus:shadow-outline transition" onclick="closeBetModal()">
                    Annulla
                </button>
                <?php // --- MODIFICATO: Bottone conferma disabilitato in conclave --- ?>
                <button type="submit"
                        id="confirmBetButton"
                        class="<?php echo $conclave_mode_active ? 'conclave-disabled-btn' : 'gradient-btn'; ?> font-bold py-3 px-6 rounded-lg focus:outline-none focus:shadow-outline"
                        <?php echo $conclave_mode_active ? 'disabled' : ''; ?>>
                    <?php echo $conclave_mode_active ? '<i class="fas fa-lock mr-1"></i> Chiuso' : 'Conferma scommessa'; ?>
                </button>
                 <?php // --- FINE MODIFICA --- ?>
            </div>
        </form>
    </div>
</div>

<!-- Modal per eliminare la scommessa -->
<div id="deleteBetModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-2xl shadow-lg w-full max-w-md modal-content">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-gray-800">Elimina scommessa</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" onclick="closeDeleteBetModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <p class="text-gray-600 mb-4" id="deleteBetText">Sei sicuro di voler eliminare questa scommessa?</p>

        <?php if (!$conclave_mode_active): // Mostra avviso solo se non è conclave ?>
        <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-triangle text-yellow-400"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-yellow-700">
                        Eliminando la scommessa, l'importo verrà riaccreditato sul tuo saldo.
                    </p>
                </div>
            </div>
        </div>
        <?php else: // Mostra messaggio diverso se è conclave (anche se il bottone sarà disabilitato) ?>
         <div class="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-lock text-red-400"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-red-700">
                        L'eliminazione delle scommesse è disabilitata durante la modalità Conclave.
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>


        <form id="deleteBetForm" method="POST" action="index.php"> <?php /* Action rimane index.php, JS intercetta */ ?>
            <input type="hidden" name="action" value="deleteBet">
            <input type="hidden" id="delete_bet_id" name="bet_id" value="">

            <div class="flex justify-end">
                <button type="button" class="mr-3 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-3 px-6 rounded-lg" onclick="closeDeleteBetModal()">
                    Annulla
                </button>
                 <?php // --- MODIFICATO: Bottone elimina disabilitato in conclave --- ?>
                <button type="submit"
                        id="confirmDeleteBetButton"
                        class="<?php echo $conclave_mode_active ? 'bg-red-300 cursor-not-allowed' : 'bg-red-500 hover:bg-red-600'; ?> text-white font-bold py-3 px-6 rounded-lg"
                        <?php echo $conclave_mode_active ? 'disabled' : ''; ?>>
                    <?php echo $conclave_mode_active ? '<i class="fas fa-lock mr-1"></i> Chiuso' : 'Elimina scommessa'; ?>
                </button>
                 <?php // --- FINE MODIFICA --- ?>
            </div>
        </form>
    </div>
</div>

<!-- Modal per visualizzare gli scommettitori -->
<div id="bettorsModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-2xl shadow-lg w-full max-w-2xl modal-content max-h-[80vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4 border-b pb-3">
            <h3 class="text-xl font-bold text-gray-800" id="bettorsModalTitle">Scommesse su Cardinale</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" onclick="closeBettorsModal()">
                <i class="fas fa-times fa-lg"></i>
            </button>
        </div>

        <div id="bettorsModalContent" class="text-gray-600 mt-4">
            <!-- Contenuto caricato via AJAX -->
            <div class="flex justify-center items-center py-8">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-[#ff930f]"></div>
                <span class="ml-3 text-gray-500">Caricamento scommettitori...</span>
            </div>
        </div>
    </div>
</div>

<!-- Modal per visualizzare le scommesse dell'utente -->
<div id="userBetsModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white p-6 rounded-2xl shadow-lg w-full max-w-3xl modal-content max-h-[80vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4 border-b pb-3">
            <h3 class="text-xl font-bold text-gray-800">Le tue scommesse</h3>
            <button type="button" class="text-gray-500 hover:text-gray-700" onclick="closeUserBetsModal()">
                <i class="fas fa-times fa-lg"></i>
            </button>
        </div>

        <?php if (count($userBets) > 0): ?>
            <div class="mb-6 bg-gray-50 p-4 rounded-lg">
                <div class="flex justify-between mb-2">
                    <p class="text-gray-600">Totale scommesso:</p>
                    <p class="font-semibold text-[#ff930f]">€<?php echo number_format($totalAmountBet, 2, ',', '.'); ?></p>
                </div>
                <div class="flex justify-between">
                    <p class="text-gray-600">Saldo disponibile:</p>
                    <p class="font-semibold text-[#ff930f]">€<?php echo number_format($_SESSION['balance'], 2, ',', '.'); ?></p>
                </div>
            </div>

             <?php if ($conclave_mode_active): ?>
                <p class="text-sm text-center text-yellow-700 bg-yellow-50 p-3 rounded mb-4"><i class="fas fa-lock mr-1"></i> Le azioni Modifica ed Elimina sono disabilitate durante il Conclave.</p>
            <?php endif; ?>

            <div class="overflow-hidden rounded-lg border border-gray-200">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cardinale</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quota</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Importo</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Azioni</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($userBets as $cardinalId => $betAmount): ?>
                            <?php
                            // Trova il cardinale corrispondente
                            $cardinalInfo = null;
                            foreach ($cardinals as $c) { // Usa variabile diversa per evitare conflitti
                                if ($c['id'] == $cardinalId) {
                                    $cardinalInfo = $c;
                                    break;
                                }
                            }

                            if (!$cardinalInfo) continue; // Salta se il cardinale non è più disponibile?
                            ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10">
                                            <?php if (!empty($cardinalInfo['image_url'])): ?>
                                                <img class="h-10 w-10 rounded-full object-cover" src="<?php echo htmlspecialchars($cardinalInfo['image_url']); ?>" alt="">
                                            <?php else: ?>
                                                <div class="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                                    <i class="fas fa-user text-gray-500"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($cardinalInfo['name']); ?></div>
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($cardinalInfo['nation']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"><?php echo number_format($cardinalInfo['bookmaker_odds'], 2, ',', '.'); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-[#ff930f]">€<?php echo number_format($betAmount, 2, ',', '.'); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <?php // --- MODIFICATO: Azioni disabilitate in conclave --- ?>
                                    <?php if (!$conclave_mode_active): ?>
                                        <button onclick="openBetModal(<?php echo $cardinalId; ?>, '<?php echo addslashes(htmlspecialchars($cardinalInfo['name'])); ?>', <?php echo $betAmount; ?>); closeUserBetsModal();" class="text-[#ff930f] hover:text-[#ffcc33] mr-3" title="Modifica Scommessa">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="openDeleteBetModal(<?php echo $userBetsIds[$cardinalId]; ?>, '<?php echo addslashes(htmlspecialchars($cardinalInfo['name'])); ?>', <?php echo $betAmount; ?>); closeUserBetsModal();" class="text-red-500 hover:text-red-700" title="Elimina Scommessa">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    <?php else: ?>
                                        <span class="text-gray-400 italic text-xs">Scommesse chiuse</span>
                                    <?php endif; ?>
                                     <?php // --- FINE MODIFICA --- ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="bg-gray-50 rounded-lg p-8 text-center">
                <div class="text-gray-400 text-6xl mb-4">
                    <i class="fas fa-coins"></i>
                </div>
                <h4 class="text-xl font-semibold text-gray-700 mb-2">Nessuna scommessa attiva</h4>
                <p class="text-gray-600 mb-4">Non hai ancora piazzato nessuna scommessa. Sfoglia i cardinali e inizia a scommettere!</p>
                <button onclick="closeUserBetsModal()" class="gradient-btn font-bold py-2 px-4 rounded-lg">
                    Vai alle scommesse
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// --- NUOVO: Passa lo stato del conclave a JavaScript ---
const isConclaveModeActive = <?php echo json_encode($conclave_mode_active); ?>;
// --- FINE NUOVO ---


// --- MODIFICATO: Listener per il form di scommessa con check Conclave ---
document.getElementById('betForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Previene l'invio standard del form

    // --- NUOVO: Check Conclave Mode lato client ---
    if (isConclaveModeActive) {
        showNotification('La modalità Conclave è attiva. Non è possibile piazzare scommesse.', 'warning');
        return; // Blocca l'invio
    }
    // --- FINE NUOVO ---


    const cardinalId = document.getElementById('cardinal_id').value;
    const betAmountInput = document.getElementById('bet_amount');
    const betAmount = parseFloat(betAmountInput.value);
    const currentBalance = parseFloat(
        document.getElementById('userBalance').innerText
            .replace(/\./g, '') // Rimuove i punti delle migliaia
            .replace(',', '.') // Sostituisce la virgola con il punto
    );

    // Verifica validità dell'importo
    if (isNaN(betAmount) || betAmount <= 0) {
        alert('Inserisci un importo valido (maggiore di zero).');
        betAmountInput.focus();
        return;
    }

    // Verifica saldo sufficiente (considera l'eventuale scommessa esistente per l'aggiornamento)
    // Nota: La logica precisa del saldo per l'aggiornamento è gestita meglio lato server.
    // Qui facciamo un controllo semplice.
    // Il controllo più robusto sul saldo necessario per l'aggiornamento è fatto nel PHP.
    // Qui potremmo solo verificare che l'importo *nuovo* non sia maggiore del saldo *totale*.
    if (betAmount > currentBalance && !document.querySelector(`.badge-bet[data-cardinal-id="${cardinalId}"]`)) { // Controllo semplice per nuova scommessa
         alert('Saldo insufficiente per piazzare questa scommessa.');
         return;
     }
     // Per l'aggiornamento, il controllo PHP è più accurato


    // Mostra un indicatore di caricamento (opzionale)
    const submitButton = document.getElementById('confirmBetButton');
    const originalButtonText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Elaborazione...';
    submitButton.disabled = true;


    // Invia il form in AJAX
    const formData = new FormData(this);

    fetch('index.php', { // L'URL dell'action del form
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            // Se la risposta non è OK (es. errore 500), lancia un errore
            throw new Error(`Errore HTTP: ${response.status}`);
        }
        return response.text(); // Ottieni il corpo della risposta come testo (HTML)
    })
    .then(html => {
        // Ricarica la pagina per mostrare i risultati aggiornati e i messaggi dal server
        // Questo è il modo più semplice per garantire che tutto sia aggiornato.
        location.reload();

        // Alternativa (più complessa): aggiornare dinamicamente parti della pagina
        // richiederebbe di parsare l'HTML ricevuto o avere un endpoint API JSON.
        // closeBetModal();
        // showNotification('Operazione completata.', 'success'); // Messaggio generico
        // Aggiornare dinamicamente saldo, badge, totali (molto complesso da fare bene qui)

    })
    .catch(error => {
        console.error('Errore durante la scommessa:', error);
        showNotification('Si è verificato un errore durante l\'invio. Riprova più tardi.', 'error');
        // Ripristina il bottone in caso di errore
        submitButton.innerHTML = originalButtonText;
        submitButton.disabled = isConclaveModeActive; // Riabilita solo se non in conclave
        closeBetModal(); // Chiudi comunque il modal
    });
});


// --- MODIFICATO: Listener per il form di eliminazione scommessa con check Conclave ---
document.getElementById('deleteBetForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Previene l'invio standard

    // --- NUOVO: Check Conclave Mode lato client ---
    if (isConclaveModeActive) {
        showNotification('La modalità Conclave è attiva. Non è possibile eliminare scommesse.', 'warning');
        return; // Blocca l'invio
    }
    // --- FINE NUOVO ---

    const submitButton = document.getElementById('confirmDeleteBetButton');
    const originalButtonText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Eliminazione...';
    submitButton.disabled = true;

    const formData = new FormData(this);

    fetch('index.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Errore HTTP: ${response.status}`);
        }
        return response.text();
    })
    .then(html => {
        // Ricarica la pagina per aggiornare lo stato
        location.reload();
    })
    .catch(error => {
        console.error('Errore durante l\'eliminazione della scommessa:', error);
        showNotification('Si è verificato un errore durante l\'eliminazione. Riprova.', 'error');
        submitButton.innerHTML = originalButtonText;
        submitButton.disabled = isConclaveModeActive;
        closeDeleteBetModal();
    });
});



// Funzioni per aprire/chiudere i modal (invariate, ma i bottoni che le chiamano sono condizionati)

function openBetModal(cardinalId, cardinalName, currentBet) {
    // Non aprire se in modalità conclave (il bottone dovrebbe essere già disabilitato, ma doppia sicurezza)
    if (isConclaveModeActive) return;

    document.getElementById('modalTitle').innerText = 'Scommetti su ' + cardinalName;
    document.getElementById('cardinal_id').value = cardinalId;

    const betAmountInput = document.getElementById('bet_amount');
    // Formatta l'importo corrente per l'input number (usa il punto come separatore decimale)
    betAmountInput.value = currentBet > 0 ? parseFloat(currentBet).toFixed(2) : '';
    betAmountInput.disabled = false; // Assicurati che sia abilitato (anche se PHP lo fa)

    // Aggiorna il max dell'input basato sul saldo corrente E la scommessa esistente
    // Se sto modificando, il max è saldo_corrente + importo_scommessa_attuale
    const currentBalance = parseFloat(
         document.getElementById('userBalance').innerText
            .replace(/\./g, '') // Rimuove i punti delle migliaia
            .replace(',', '.') // Sostituisce la virgola con il punto
    );
    const maxBet = currentBalance + (currentBet > 0 ? parseFloat(currentBet) : 0);
    betAmountInput.max = maxBet.toFixed(2);


    document.getElementById('betModal').classList.remove('hidden');
    betAmountInput.focus(); // Focus sull'input
}


function closeBetModal() {
    document.getElementById('betModal').classList.add('hidden');
}

function openDeleteBetModal(betId, cardinalName, betAmount) {
     // Non aprire se in modalità conclave
    if (isConclaveModeActive) return;

    document.getElementById('delete_bet_id').value = betId;
    const formattedAmount = parseFloat(betAmount).toLocaleString('it-IT', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    document.getElementById('deleteBetText').innerHTML =
        `Sei sicuro di voler eliminare la tua scommessa di <span class="font-semibold">€${formattedAmount}</span> su <span class="font-semibold">${cardinalName}</span>?`;

    document.getElementById('deleteBetModal').classList.remove('hidden');
}


function closeDeleteBetModal() {
    document.getElementById('deleteBetModal').classList.add('hidden');
}

function showBettorsModal(cardinalId, cardinalName) {
    document.getElementById('bettorsModalTitle').innerText = 'Scommesse su ' + cardinalName;
    document.getElementById('bettorsModalContent').innerHTML = `
        <div class="flex justify-center items-center py-8">
            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-[#ff930f]"></div>
            <span class="ml-3 text-gray-500">Caricamento scommettitori...</span>
        </div>`;
    document.getElementById('bettorsModal').classList.remove('hidden');

    fetch(`get_bettors.php?cardinal_id=${cardinalId}`)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok.');
            return response.json();
        })
        .then(data => {
            const contentDiv = document.getElementById('bettorsModalContent');

            if (data.error) {
                contentDiv.innerHTML = `
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                        <p>${data.error}</p>
                    </div>`;
                return;
            }

            if (!data.bettors || data.bettors.length === 0) {
                contentDiv.innerHTML = `
                    <div class="bg-gray-50 rounded-lg p-8 text-center">
                        <div class="text-gray-400 text-6xl mb-4">
                            <i class="fas fa-user-times"></i>
                        </div>
                        <h4 class="text-xl font-semibold text-gray-700 mb-2">Nessuna scommessa</h4>
                        <p class="text-gray-600">Non ci sono ancora scommesse registrate per questo cardinale.</p>
                    </div>`;
                return;
            }

            // Totali formattati
            const totalBettors = parseInt(data.total_bettors).toLocaleString('it-IT');
            const totalAmount = parseFloat(data.total_amount).toLocaleString('it-IT', {
                style: 'currency', currency: 'EUR'
            });

            let bettorsHTML = `
                <div class="mb-6 bg-gray-50 p-4 rounded-lg">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-center sm:text-left">
                        <div>
                            <p class="text-gray-600 text-sm uppercase tracking-wider font-medium">Totale Scommettitori</p>
                            <p class="font-semibold text-2xl text-[#ff930f]">${totalBettors}</p>
                        </div>
                        <div>
                            <p class="text-gray-600 text-sm uppercase tracking-wider font-medium">Importo Totale Scommesso</p>
                            <p class="font-semibold text-2xl text-[#ff930f]">${totalAmount}</p>
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <h4 class="font-semibold text-lg text-gray-700 mb-2">Dettaglio Scommesse</h4>
                </div>

                <div class="overflow-hidden rounded-lg border border-gray-200 max-h-[40vh] overflow-y-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-100 sticky top-0 z-10">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utente</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Importo</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
            `;

            data.bettors.forEach(bettor => {
                const fmtAmt = parseFloat(bettor.amount).toLocaleString('it-IT', {
                    style: 'currency', currency: 'EUR'
                });
                const fmtDate = bettor.created_at
                    ? new Date(bettor.created_at).toLocaleDateString('it-IT', { year: 'numeric', month: 'short', day: 'numeric' })
                    : 'N/D';

                // Qui mostriamo sempre il nome utente (o fallback minimale se mancante)
                const usernameDisplay = htmlspecialchars(bettor.username || '—');

                bettorsHTML += `
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">${usernameDisplay}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-800">${fmtAmt}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            ${fmtDate}
                        </td>
                    </tr>
                `;
            });

            bettorsHTML += `
                        </tbody>
                    </table>
                </div>`;

            contentDiv.innerHTML = bettorsHTML;
        })
        .catch(error => {
            console.error('Errore durante il recupero dei dati degli scommettitori:', error);
            document.getElementById('bettorsModalContent').innerHTML = `
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                    <p class="font-bold">Errore</p>
                    <p>Si è verificato un problema durante il recupero dei dati. Riprova più tardi.</p>
                </div>`;
        });
}


function closeBettorsModal() {
    document.getElementById('bettorsModal').classList.add('hidden');
    document.getElementById('bettorsModalContent').innerHTML = ''; // Pulisci contenuto altrimenti mostra il vecchio brevemente
}

function showUserBetsModal() {
    document.getElementById('userBetsModal').classList.remove('hidden');
}

function closeUserBetsModal() {
    document.getElementById('userBetsModal').classList.add('hidden');
}

// Funzione per mostrare notifiche (invariata)
function showNotification(message, type) {
    const notificationArea = document.getElementById('notificationArea') || createNotificationArea();
    const notificationId = 'notification-' + Date.now();

    const bgColor = type === 'error' ? 'bg-red-100' : (type === 'success' ? 'bg-green-100' : 'bg-yellow-100');
    const textColor = type === 'error' ? 'text-red-700' : (type === 'success' ? 'text-green-700' : 'text-yellow-700');
    const borderColor = type === 'error' ? 'border-red-500' : (type === 'success' ? 'border-green-500' : 'border-yellow-500');
    const icon = type === 'error' ? 'fa-exclamation-circle' : (type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle');
    const iconColor = type === 'error' ? 'text-red-500' : (type === 'success' ? 'text-green-500' : 'text-yellow-500');

    const notificationHTML = `
        <div id="${notificationId}" class="relative mb-3 p-4 rounded-lg shadow-lg ${bgColor} ${textColor} border-l-4 ${borderColor} animate-fadeIn flex items-start transition-opacity duration-500 ease-out" role="alert">
            <div class="flex-shrink-0 mr-3">
                <i class="fas ${icon} ${iconColor}"></i>
            </div>
            <div class="flex-grow">
                ${htmlspecialchars(message)}
            </div>
            <button onclick="closeNotification('${notificationId}')" class="ml-4 text-gray-500 hover:text-gray-700 text-lg">×</button>
        </div>
    `;

    notificationArea.insertAdjacentHTML('beforeend', notificationHTML);

    // Auto-chiusura dopo 5 secondi
    setTimeout(() => {
        closeNotification(notificationId);
    }, 5000);
}

function createNotificationArea() {
    let area = document.getElementById('notificationArea');
    if (!area) {
        area = document.createElement('div');
        area.id = 'notificationArea';
        area.className = 'fixed top-5 right-5 z-[100] w-full max-w-sm'; // Posiziona in alto a destra, sopra tutto
        document.body.appendChild(area);
    }
    return area;
}

function closeNotification(id) {
    const notification = document.getElementById(id);
    if (notification) {
        notification.classList.add('opacity-0');
        // Aspetta la fine della transizione prima di rimuovere
        setTimeout(() => {
            notification.remove();
             // Rimuovi l'area se è vuota
             const area = document.getElementById('notificationArea');
             if (area && area.children.length === 0) {
                 // area.remove(); // Opzionale: rimuovere l'area se vuota
             }
        }, 500); // Deve corrispondere alla durata della transizione
    }
}

// Funzione helper per escape HTML in JS (necessaria per showNotification)
function htmlspecialchars(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/&/g, '&')
              .replace(/</g, '<')
              .replace(/>/g, '>')
              .replace(/"/g, '"')
              ;
}

// Assicurati che l'area notifiche esista al caricamento
document.addEventListener('DOMContentLoaded', createNotificationArea);
// Tasto esc modali

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' || e.key === 'Esc') {
        closeBetModal();
        closeBettorsModal();
        closeDeleteBetModal();
        closeUserBetsModal();
    }
});


</script>

<?php
// Includi il footer
includeFooter();
?>