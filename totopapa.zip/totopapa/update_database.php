<?php
// update_database.php
// Si assicura che esista la tabella `settings` e che contenga la chiave `conclave`.

require_once 'config.php';

try {
    // Otteniamo la connessione dal config
    $db = getDbConnection();
    
    // 1) Creazione tabella settings, se non esiste (sintassi compatibile anche con SQLite)
    $db->exec("
        CREATE TABLE IF NOT EXISTS settings (
            name VARCHAR(100) PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );
    ");
    
    // 2) Inserimento chiave 'conclave' con valore di default '0', se non esiste già
    $stmt = $db->prepare("
        INSERT INTO settings (name, value)
        SELECT :name, :value
        WHERE NOT EXISTS (
            SELECT 1 FROM settings WHERE name = :name
        )
    ");
    $stmt->execute([
        ':name'  => 'conclave',
        ':value' => '0'
    ]);
    
    echo "Tabella `settings` pronta e chiave 'conclave' assicurata.";
    
} catch (PDOException $e) {
    echo "Errore durante l'aggiornamento del database: " . $e->getMessage();
    exit;
}
