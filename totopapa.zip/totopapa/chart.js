// chart.js

// URL assoluto (o relativo alla root) dove risiede il tuo API
const API_URL = '/totopapa/get_top_cardinal.php';

// Funzione per caricare la chart (viene chiamata una sola volta)
function initTopCardinalChart() {
  fetch(API_URL)
    .then(res => {
      if (!res.ok) throw new Error('Fetch JSON fallito: ' + res.status);
      return res.json();
    })
    .then(data => {
      const canvas = document.getElementById('topCardinalChartCanvas');
      if (!canvas) throw new Error('Canvas non trovato');
      const ctx = canvas.getContext('2d');

      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: [data.name],
          datasets: [{
            label: '€ totali scommessi',
            data: [data.total_amount],
            backgroundColor: 'rgba(255,147,15,0.8)',
            borderRadius: 8,
            barThickness: 40
          }]
        },
        options: {
          indexAxis: 'y',
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: { label: ctx => ctx.formattedValue + ' €' } }
          },
          scales: {
            x: { ticks: { callback: v => v + ' €' } }
          }
        },
        plugins: [{
          id: 'faceOverlay',
          afterDatasetsDraw(chart) {
            const { ctx, getDatasetMeta } = chart;
            const meta = getDatasetMeta(0);
            const bar = meta.data[0];
            const img = new Image();
            img.src = data.image_url;
            img.onload = () => {
              const size = bar.height * 1.2;
              const xPos = bar.x - bar.width / 2 - size - 8;
              const yPos = bar.y - size / 2;
              ctx.save();
              ctx.beginPath();
              ctx.arc(xPos + size/2, yPos + size/2, size/2, 0, Math.PI*2);
              ctx.clip();
              ctx.drawImage(img, xPos, yPos, size, size);
              ctx.restore();
            };
          }
        }]
      });
    })
    .catch(err => console.error('Errore initTopCardinalChart:', err));
}

// Esporto le funzioni di apertura/chiusura come globali
window.openTopCardinalChartModal = function() {
  const modal = document.getElementById('topCardinalChartModal');
  if (!modal) return;
  modal.classList.remove('hidden');
  if (!window.__topChartInitialized) {
    window.__topChartInitialized = true;
    initTopCardinalChart();
  }
};

window.closeTopCardinalChartModal = function() {
  const modal = document.getElementById('topCardinalChartModal');
  if (!modal) return;
  modal.classList.add('hidden');
};
