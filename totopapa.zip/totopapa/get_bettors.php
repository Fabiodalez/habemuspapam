<?php
// get_bettors.php - API per ottenere i dati degli scommettitori per un cardinale specifico

require_once 'config.php';

// Prepara la risposta
header('Content-Type: application/json');

// Verifica che l'utente sia loggato
if (!isLoggedIn()) {
    echo json_encode(['error' => 'Utente non autenticato']);
    exit;
}

// Verifica che sia stato fornito un ID cardinale
if (empty($_GET['cardinal_id'])) {
    echo json_encode(['error' => 'ID cardinale non specificato']);
    exit;
}

$cardinalId = (int)$_GET['cardinal_id'];

try {
    $db = getDbConnection();
    
    // Verifica che il cardinale esista
    $stmt = $db->prepare('SELECT id, name FROM cardinals WHERE id = :id');
    $stmt->bindParam(':id', $cardinalId, PDO::PARAM_INT);
    $stmt->execute();
    $cardinal = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cardinal) {
        echo json_encode(['error' => 'Cardinale non trovato']);
        exit;
    }
    
    // Recupera i dati sulle scommesse per questo cardinale
    $stmt = $db->prepare('
        SELECT 
            b.id, 
            b.user_id, 
            u.username, 
            b.amount, 
            b.created_at 
        FROM 
            bets b
        JOIN 
            users u ON b.user_id = u.id
        WHERE 
            b.cardinal_id = :cardinal_id
        ORDER BY 
            b.created_at DESC
    ');
    $stmt->bindParam(':cardinal_id', $cardinalId, PDO::PARAM_INT);
    $stmt->execute();
    $bettors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calcola i totali
    $totalBettors = count($bettors);
    $totalAmount = array_reduce($bettors, function($sum, $b) {
        return $sum + $b['amount'];
    }, 0);
    
    // Prepara la risposta: tutti vedono i nomi utente reali
    $response = [
        'cardinal'      => [
            'id'   => $cardinal['id'],
            'name' => $cardinal['name'],
        ],
        'total_bettors' => $totalBettors,
        'total_amount'  => $totalAmount,
        'bettors'       => $bettors
    ];
    
    echo json_encode($response);
    
} catch (PDOException $e) {
    echo json_encode(['error' => 'Errore di database: ' . $e->getMessage()]);
    exit;
} catch (Exception $e) {
    echo json_encode(['error' => 'Errore generale: ' . $e->getMessage()]);
    exit;
}
