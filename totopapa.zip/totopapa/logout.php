<?php
// logout.php - Gestisce il logout dell'utente

// Includi il file di configurazione
require_once 'config.php';

// Controllo di sicurezza: verifica che l'utente sia effettivamente loggato
if (!isLoggedIn()) {
    // Se l'utente non è loggato, reindirizza direttamente alla pagina di login
    header('Location: login.php');
    exit;
}

// Memorizza l'username per il messaggio di logout
$username = $_SESSION['username'] ?? 'Utente';

// Elimina tutte le variabili di sessione
$_SESSION = array();

// Se è stata inviata anche la sessione tramite cookie, distruggila
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Distruggi la sessione
session_destroy();

// Reindirizza alla pagina di login con un messaggio di successo
// Usa header() direttamente invece della funzione redirect()
header('Location: login.php?logout=success&username=' . urlencode($username));
exit;
?>