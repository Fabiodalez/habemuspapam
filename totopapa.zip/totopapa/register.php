<?php
// register.php - Pagina di registrazione utenti
require_once 'config.php';

$error = '';
$success = '';

// Controllo se l'utente ha già effettuato il login
if (isLoggedIn()) {
    redirect('index.php');
}

// Gestione del form di registrazione
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $email = $_POST['email'] ?? '';
    $fullName = $_POST['full_name'] ?? '';
    
    // Validazione
    if (empty($username) || empty($password) || empty($confirmPassword) || empty($email)) {
        $error = 'I campi username, email, password e conferma password sono obbligatori';
    } elseif ($password !== $confirmPassword) {
        $error = 'Le password non corrispondono';
    } elseif (strlen($password) < 6) {
        $error = 'La password deve essere di almeno 6 caratteri';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Inserisci un indirizzo email valido';
    } else {
        try {
            $db = getDbConnection();
            
            // Verifica che l'username non sia già in uso
            $stmt = $db->prepare('SELECT COUNT(*) FROM users WHERE username = :username');
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            
            if ($stmt->fetchColumn() > 0) {
                $error = 'L\'username è già in uso, per favore scegline un altro';
            } else {
                // Verifica che l'email non sia già in uso
                $stmt = $db->prepare('SELECT COUNT(*) FROM users WHERE email = :email');
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                
                if ($stmt->fetchColumn() > 0) {
                    $error = 'L\'indirizzo email è già associato a un account esistente';
                } else {
                    // Registra il nuovo utente
                    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                    $initialBalance = DEFAULT_BALANCE;
                    $isAdmin = 0; // Utente normale, non admin
                    
                    $stmt = $db->prepare('
                        INSERT INTO users (username, password, email, full_name, balance, is_admin) 
                        VALUES (:username, :password, :email, :full_name, :balance, :is_admin)
                    ');
                    $stmt->bindParam(':username', $username);
                    $stmt->bindParam(':password', $passwordHash);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':full_name', $fullName);
                    $stmt->bindParam(':balance', $initialBalance);
                    $stmt->bindParam(':is_admin', $isAdmin);
                    $stmt->execute();
                    
                    // Reindirizza alla pagina di login con messaggio di successo
                    redirect('login.php?register=success');
                }
            }
        } catch (PDOException $e) {
            $error = 'Errore durante la registrazione: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrazione - PapalBet</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f8f9fa;
            background-image: url('https://sirmilano.it/wp-content/uploads/2022/01/WhatsApp-Image-2022-01-17-at-09.06.36.jpeg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        
        .gradient-btn {
            background: linear-gradient(to top, #ff930f, #ffcc33);
            color: white;
            transition: all 0.3s ease;
            border: none;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        
        .gradient-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 147, 15, 0.4);
        }
        
        .gradient-btn::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, #ff930f, #ffcc33);
            opacity: 0;
            z-index: -1;
            transition: opacity 0.3s ease;
        }
        
        .gradient-btn:hover::after {
            opacity: 1;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fadeIn {
            animation: fadeIn 0.5s ease forwards;
        }
        
        .card {
            backdrop-filter: blur(10px);
            background-color: rgba(255, 255, 255, 0.9);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="card p-8 rounded-2xl shadow-lg w-full max-w-md animate-fadeIn">
        <div class="text-center mb-8">
            <h1 class="text-4xl font-bold text-[#ff930f] mb-2">Registrazione</h1>
            <p class="text-gray-600">Crea un account per Habemus Papam</p>
        </div>
        
        <?php if ($error): ?>
            <div class="mb-6 p-4 rounded-lg shadow-sm bg-red-100 text-red-700 border-l-4 border-red-500">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-circle text-red-500"></i>
                    </div>
                    <div class="ml-3">
                        <?php echo $error; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Form di registrazione -->
        <form method="POST" action="register.php">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Username <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <i class="fas fa-user text-gray-400"></i>
                    </div>
                    <input class="shadow appearance-none border border-gray-300 rounded-lg w-full py-3 pl-10 pr-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-[#ff930f] focus:border-transparent" 
                        id="username" 
                        name="username" 
                        type="text" 
                        value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                        placeholder="Scegli un username"
                        required>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="email">
                    Email <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <i class="fas fa-envelope text-gray-400"></i>
                    </div>
                    <input class="shadow appearance-none border border-gray-300 rounded-lg w-full py-3 pl-10 pr-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-[#ff930f] focus:border-transparent" 
                        id="email" 
                        name="email" 
                        type="email" 
                        value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                        placeholder="La tua email"
                        required>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="full_name">
                    Nome completo
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <i class="fas fa-id-card text-gray-400"></i>
                    </div>
                    <input class="shadow appearance-none border border-gray-300 rounded-lg w-full py-3 pl-10 pr-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-[#ff930f] focus:border-transparent" 
                        id="full_name" 
                        name="full_name" 
                        type="text" 
                        value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>"
                        placeholder="Il tuo nome e cognome">
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="password">
                    Password <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <i class="fas fa-lock text-gray-400"></i>
                    </div>
                    <input class="shadow appearance-none border border-gray-300 rounded-lg w-full py-3 pl-10 pr-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-[#ff930f] focus:border-transparent" 
                        id="password" 
                        name="password" 
                        type="password" 
                        placeholder="Scegli una password"
                        required>
                </div>
                <p class="text-sm text-gray-500 mt-1">La password deve essere di almeno 6 caratteri</p>
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="confirm_password">
                    Conferma Password <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <i class="fas fa-lock text-gray-400"></i>
                    </div>
                    <input class="shadow appearance-none border border-gray-300 rounded-lg w-full py-3 pl-10 pr-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-[#ff930f] focus:border-transparent" 
                        id="confirm_password" 
                        name="confirm_password" 
                        type="password" 
                        placeholder="Ripeti la password"
                        required>
                </div>
            </div>
            
            <div class="mb-6">
                <div class="flex items-center">
                    <input id="terms" name="terms" type="checkbox" required class="h-4 w-4 text-[#ff930f] focus:ring-[#ff930f] border-gray-300 rounded">
                    <label for="terms" class="ml-2 block text-sm text-gray-700">
                        Accetto i <a href="terms.php" class="text-[#ff930f] hover:underline">Termini di Servizio</a> e la <a href="terms.php" class="text-[#ff930f] hover:underline">Privacy Policy</a>
                    </label>
                </div>
            </div>
            
            <div class="flex items-center justify-between mb-6">
                <button class="gradient-btn w-full font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline" 
                    type="submit">
                    Registrati
                </button>
            </div>
            
            <div class="text-center">
                <p class="text-sm text-gray-600 mb-2">
                    Hai già un account?
                </p>
                <a href="login.php" class="inline-block text-[#ff930f] hover:text-[#ffcc33] font-medium">
                    Accedi <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
        </form>
    </div>
</body>
</html>